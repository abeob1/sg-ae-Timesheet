//
//  MyEntryViewController.m
//  Timesheet
//
//  Created by electra on 1/11/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import "MyEntryViewController.h"

@interface MyEntryViewController ()

@end

@implementation MyEntryViewController
{
    UIToolbar *toolBar;
    NSDictionary *o1;
    NSInteger totalScetions;
    UIActivityIndicatorView *activity;
}
@synthesize FromDateTxt,ToDateTxt,FilterButtonOutlet,TableviewOutlet,DropdownTxtOutlet,Dropdown1TxtOutlet;

- (void)viewDidLoad {
    [super viewDidLoad];

    NoDataFoundLabelOutlet.text=@"No Data Found";
    FilterButtonOutlet.layer.borderWidth=1.5;
    [[FilterButtonOutlet layer] setBorderColor:[UIColor whiteColor].CGColor];
    dropDownTableView=[[UITableView alloc]init];
    dropDownTableView1=[[UITableView alloc]init];

    datePicker = [[UIDatePicker alloc]init];
    datePicker.datePickerMode = UIDatePickerModeDate;
    [datePicker setBackgroundColor:[UIColor whiteColor]];
    toolBar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,35)];
    toolBar.barStyle = UIBarStyleBlackTranslucent;

    [toolBar setTintColor:[UIColor whiteColor]];
    [toolBar setBackgroundColor:[UIColor colorWithRed:(5.0 / 255.0) green:(133.0 / 255.0) blue:(252.0 / 255.0) alpha: 1]];
    toolBar.alpha =1.0;
    UIBarButtonItem *doneBtn = [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(ShowSelectedDate)];
    UIBarButtonItem *space = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [toolBar setItems:[NSArray arrayWithObjects:space,doneBtn, nil]];
    typeArray=[[NSMutableArray alloc]initWithObjects:@"New",@"Approved",@"Pending for Approval",@"Posted to SAP", nil];
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    UserString=appDelegate.UserName;
    
    FromDateTxt.rightViewMode = UITextFieldViewModeAlways;
    FromDateTxt.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"calendar.png"]];
      // _HeaderView = [self.storyboard instantiateViewControllerWithIdentifier:@"AddViewController"];
   // _HeaderView.view.frame=HorizontalScroll.bounds;

    
    activity = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    [activity setBackgroundColor:[UIColor blueColor]];
    activity.frame = CGRectMake(round((self.view.frame.size.width - 25) / 2), round((self.view.frame.size.height - 25) / 2), 25, 25);
    //av.tag  = 1;
    [self.view addSubview:activity];


    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)FilterButtonTapped:(id)sender {
    if ([FromDateTxt.text isEqualToString:@"" ]||[ToDateTxt.text isEqualToString:@""]||[DropdownTxtOutlet.text isEqualToString:@""]) {
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Warning"
                                     message:@"Please select a Fields"
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* yesButton = [UIAlertAction
                                    actionWithTitle:@"Ok"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        //Handle your yes please button action here
                                    }];
        
        
        [alert addAction:yesButton];
        [self presentViewController:alert animated:YES completion:nil];
    }
    else
    {
        [activity startAnimating];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MGet_FilterMyEntry"]];
    NSString *FromString=FromDateTxt.text;
    FromString = [FromString stringByReplacingOccurrencesOfString:@"-" withString:@""];
    NSString *ToString=ToDateTxt.text;
    ToString = [ToString stringByReplacingOccurrencesOfString:@"-" withString:@""];

    if ([DropdownTxtOutlet.text isEqualToString:@"New"]) {
        Status=@"0";
    }
    else if ([DropdownTxtOutlet.text isEqualToString:@"Approved"])
    {
        Status=@"1";

    }
    else if ([DropdownTxtOutlet.text isEqualToString:@"Pending for Approval"])
    {
        Status=@"2";

    }
    else if ([DropdownTxtOutlet.text isEqualToString:@"Posted to SAP"])
    {
        Status=@"3";

    }
        NSString *str1=@"20170102";
        NSString *str2=@"20170107";
        NSString *str3=@"vivek_r";
        NSString *str4=@"";
        NSString *str5=@"1";

        o1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:str1,@"IN_BeginDate",str2, @"IN_EndDate",str3,@"IN_UserCode",str4,@"IN_PrjCode",str5,@"IN_Status",nil];
        /*
    int muni = [ProjectName indexOfObject:Dropdown1TxtOutlet.text];
    PrcString=[[NSString alloc]init];
    PrcString=[ProjectCode objectAtIndex:muni];
  if([PrcString length]==0)
  {
      
      o1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:FromString,@"IN_BeginDate",ToString, @"IN_EndDate",UserString,@"IN_UserCode",@"",@"IN_PrjCode",Status,@"IN_Status",nil];
  
  }
    else
    {
    o1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:FromString,@"IN_BeginDate",ToString, @"IN_EndDate",UserString,@"IN_UserCode",PrcString,@"IN_PrjCode",Status,@"IN_Status",nil];
 
    }
    */
   // FilterInputArray=[NSMutableArray arrayWithObject:o1];
    //create the Method "GET" or "POST"
    NSError *error;
    [request setHTTPMethod:@"POST"];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:o1 options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *jsonString1=[NSString stringWithFormat:@"sJsonInput=%@",jsonString];
    //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
    // NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput={'sDBName' : 'ABEO_INTL'}"];
    
    
    
    //Check The Value what we passed
    // NSLog(@"the data Details is =%@", userUpdate);
    
    //Convert the String to Data
    NSData *data1 = [jsonString1 dataUsingEncoding:NSUTF8StringEncoding];
    //[request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
    //NSLog(@"%@",InputArray);
    
    //Apply the data to the body
    [request setHTTPBody:data1];
        
        NSError *err;
        NSURLResponse *response;
        
        NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
        
        NSString *resSrt = [[NSString alloc]initWithData:responseData encoding:NSASCIIStringEncoding];
        NSLog(@"got response==%@", resSrt);
        if(resSrt)
        {
            NSLog(@"got response");
        }
        else
        {
            NSLog(@"faield to connect");
        }
        
        NSError *e = nil;
        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&e];
        NSLog(@"%@", json);
        GrandTotal=[json objectAtIndex:json.count-1];
        GrantTotalString=[GrandTotal valueForKey:@"Hour"];
        [json removeObjectAtIndex:json.count-1];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        
        // NSDateFormatter *myFormat = [[NSDateFormatter alloc] init];
        //[myFormat setDateFormat:@"yyyy-MM-dd"];
        
        [dateFormatter setDateFormat:@"dd/mm/yyyy hh:mm:ss a"];
        
        PrCode=[json valueForKey:@"PrjCode"];
        NSMutableArray *date1=[json valueForKey:@"Date"];
        PrDate=[[NSMutableArray alloc]init];
        for (int i=0; i<[date1 count];i++) {
            // NSString *dateAsStr = [[NSString alloc]init];
            NSString *dateAsStr=[date1 objectAtIndex:i];
            NSLog(@"%@",dateAsStr);
            NSArray *components = [dateAsStr componentsSeparatedByString:@" "];
            NSString *date = components[0];
            [PrDate addObject:date];
            NSLog(@"%@",PrDate);
            
        }
        NSLog(@"%@",PrDate);
        
        PrName=[json valueForKey:@"PrjName"];
        Hour=[json valueForKey:@"Hour"];
        NSLog(@"%@", json);

        if ([json count] == 1)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                NoDataFoundLabelOutlet.text=@"No Data Found";
                UIAlertController * alert = [UIAlertController
                                             alertControllerWithTitle:@"Warning"message:@"NoDataFound"
                                             preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* yesButton = [UIAlertAction
                                            actionWithTitle:@"Ok"
                                            style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction * action) {
                                                [self.navigationController popToRootViewControllerAnimated:YES];
                                                //Handle your yes please button action here
                                            }];
                
                [alert addAction:yesButton];
                
                [self presentViewController:alert animated:YES completion:nil];
                
                
            });
            
            
            
            NSLog(@"1");
            
        }
        else
        {
            NoDataFoundLabelOutlet.text=@"";
            
            dispatch_async(dispatch_get_main_queue(), ^{
                MyEntryDisplayTableView=[[UITableView alloc]initWithFrame:CGRectMake(0,DropdownTxtOutlet.layer.frame.origin.y+40,self.view.frame.size.width,self.view.frame.size.height) style:UITableViewStylePlain];
                [self.view addSubview:MyEntryDisplayTableView];
                [MyEntryDisplayTableView setBackgroundColor:[UIColor colorWithRed:(248.0 / 255.0) green:(248.0 / 255.0) blue:(249.0 / 255.0) alpha: 1]];
                MyEntryDisplayTableView.delegate=self;
                MyEntryDisplayTableView.dataSource=self;
            });
            NSLog(@"2");
            
            [MyEntryDisplayTableView reloadData];
            
        }


/*
    NSURLSessionDataTask *task =
    [[NSURLSession sharedSession] dataTaskWithRequest:request
                                    completionHandler:^(NSData *data,
                                                        NSURLResponse *response,
                                                        NSError *error) {
 
                                        NSString *resSrt = [[NSString alloc]initWithData:data encoding:NSASCIIStringEncoding];
                                        NSLog(@"got response==%@", resSrt);
 
 
                                        NSError *e = nil;
                                        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&e];
                                        GrandTotal=[json objectAtIndex:json.count-1];
                                        GrantTotalString=[GrandTotal valueForKey:@"Hour"];
                                        [json removeObjectAtIndex:json.count-1];
                                        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];

                                       // NSDateFormatter *myFormat = [[NSDateFormatter alloc] init];
                                        //[myFormat setDateFormat:@"yyyy-MM-dd"];

                                        [dateFormatter setDateFormat:@"dd/mm/yyyy hh:mm:ss a"];

                                        PrCode=[json valueForKey:@"PrjCode"];
                                         NSMutableArray *date1=[json valueForKey:@"Date"];
                                        PrDate=[[NSMutableArray alloc]init];
                                       for (int i=0; i<[date1 count];i++) {
                                           // NSString *dateAsStr = [[NSString alloc]init];
                                          NSString *dateAsStr=[date1 objectAtIndex:i];
                                            NSLog(@"%@",dateAsStr);
                                            NSArray *components = [dateAsStr componentsSeparatedByString:@" "];
                                            NSString *date = components[0];
                                                                                       [PrDate addObject:date];
                                            NSLog(@"%@",PrDate);

                                        }
                                        NSLog(@"%@",PrDate);

                                        PrName=[json valueForKey:@"PrjName"];
                                        Hour=[json valueForKey:@"Hour"];
                                        NSLog(@"%@", json);

                                        if ([json count] == 1)
                                        {
                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                NoDataFoundLabelOutlet.text=@"No Data Found";
                                                UIAlertController * alert = [UIAlertController
                                                                             alertControllerWithTitle:@"Warning"message:@"NoDataFound"
                                                                             preferredStyle:UIAlertControllerStyleAlert];
                                                
                                                UIAlertAction* yesButton = [UIAlertAction
                                                                            actionWithTitle:@"Ok"
                                                                            style:UIAlertActionStyleDefault
                                                                            handler:^(UIAlertAction * action) {
                                                                                [self.navigationController popToRootViewControllerAnimated:YES];
                                                                                //Handle your yes please button action here
                                                                            }];
                                                
                                                [alert addAction:yesButton];
                                                
                                                [self presentViewController:alert animated:YES completion:nil];
                                                
                                                
                                            });
                                           


                                            NSLog(@"1");

                                        }
                                        else
                                        {
                                            NoDataFoundLabelOutlet.text=@"";
                                            
                                            dispatch_async(dispatch_get_main_queue(), ^{
                                            MyEntryDisplayTableView=[[UITableView alloc]initWithFrame:CGRectMake(0,DropdownTxtOutlet.layer.frame.origin.y+40,self.view.frame.size.width,self.view.frame.size.height) style:UITableViewStylePlain];
                                                [self.view addSubview:MyEntryDisplayTableView];
                                                [MyEntryDisplayTableView setBackgroundColor:[UIColor colorWithRed:(248.0 / 255.0) green:(248.0 / 255.0) blue:(249.0 / 255.0) alpha: 1]];
                                                MyEntryDisplayTableView.delegate=self;
                                                MyEntryDisplayTableView.dataSource=self;
                                                                                            });
                                            NSLog(@"2");

                                            [MyEntryDisplayTableView reloadData];

                                        }
                                        // Code to run when the response completes...
                                    }];

    [task resume];
    


}
*/
        [activity stopAnimating];
}
}
- (IBAction)BackButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)LogoutButtonTapped:(id)sender {
    
    UIAlertController * alert = [UIAlertController
                                 alertControllerWithTitle:@"Confirmation"
                                 message:@"Are you sure you want to Logout"
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* yesButton = [UIAlertAction
                                actionWithTitle:@"Yes"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action) {
                                    [self.navigationController popToRootViewControllerAnimated:YES];
                                    //Handle your yes please button action here
                                }];
    
    UIAlertAction* noButton = [UIAlertAction
                               actionWithTitle:@"Cancel"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction * action) {
                                   //Handle no, thanks button
                               }];
    
    [alert addAction:yesButton];
    [alert addAction:noButton];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    // [self.navigationController popToRootViewControllerAnimated:YES];
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField==FromDateTxt) {
        
        [FromDateTxt setInputView:datePicker];
        [FromDateTxt setInputAccessoryView:toolBar];
    }
    else if (textField==ToDateTxt)
    {
        [ToDateTxt setInputView:datePicker];
        [ToDateTxt setInputAccessoryView:toolBar];
    }
    else if (textField==DropdownTxtOutlet)
    {
        [DropdownTxtOutlet resignFirstResponder];
        dropDownTableView.frame=CGRectMake(0,DropdownTxtOutlet.frame.origin.y+30,DropdownTxtOutlet.frame.size.width+30,self.view.frame.size.height/4);
        //[dropDownTableView style:(UITableViewStylePlain)];
        dropDownTableView.backgroundColor=[UIColor lightGrayColor];
        dropDownTableView.layer.cornerRadius=5;
        dropDownTableView.scrollEnabled=YES;
        [self.view addSubview:dropDownTableView];
        dropDownTableView.delegate=self;
        dropDownTableView.dataSource=self;

    }
    else if (textField==Dropdown1TxtOutlet)
    {
        [Dropdown1TxtOutlet resignFirstResponder];
        NSURL *url = [NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MGet_ProjectList"];
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
        AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
        NSString *SaveString = appDelegate.UserIdString;
        NSString *DbString=appDelegate.DbName;
        
        NSDictionary *o1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:DbString, @"sDBName",SaveString, @"sUserId",nil];
        //FilterInputArray=[NSMutableArray arrayWithObject:o1];
        //create the Method "GET" or "POST"
        NSError *error;
        [request setHTTPMethod:@"POST"];
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:o1 options:NSJSONWritingPrettyPrinted error:&error];
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSString *jsonString1=[NSString stringWithFormat:@"sJsonInput=%@",jsonString];
        
        //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
        // NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput={'sDBName' : 'ABEO_INTL'}"];
        
        
        
        //Check The Value what we passed
        // NSLog(@"the data Details is =%@", userUpdate);
        
        //Convert the String to Data
        NSData *data1 = [jsonString1 dataUsingEncoding:NSUTF8StringEncoding];
        [request setHTTPBody:data1];
        // [request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
        [request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
        NSError *err;
        NSURLResponse *response;
        
        NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
        
        NSString *resSrt = [[NSString alloc]initWithData:responseData encoding:NSASCIIStringEncoding];
        NSLog(@"got response==%@", resSrt);
        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&err];
        NSLog(@"%@", json);
        ProjectName=[[NSMutableArray alloc]init];
        ProjectCode=[json valueForKey:@"PrjCode"];
        ProjectName=[json valueForKey:@"PrjName"];
        
        
        if ([ProjectName count] == 0)
        {
            
        }
        else
        {
            dropDownTableView1.frame=CGRectMake(Dropdown1TxtOutlet.frame.origin.x,Dropdown1TxtOutlet.frame.origin.y+30,Dropdown1TxtOutlet.frame.size.width+40,self.view.frame.size.height/4);
            //[dropDownTableView style:(UITableViewStylePlain)];
            dropDownTableView1.backgroundColor=[UIColor lightGrayColor];
            dropDownTableView.layer.cornerRadius=5;
            dropDownTableView1.scrollEnabled=YES;
            [self.view addSubview:dropDownTableView1];
            dropDownTableView1.dataSource=self;
            dropDownTableView1.delegate=self;
        }


    }
}
-(void)ShowSelectedDate
{
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"YYYY-MM-dd"];
    if ([FromDateTxt isFirstResponder])
    {
        FromDateTxt.text=[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]];
        [FromDateTxt resignFirstResponder];
    }
    else if ([ToDateTxt resignFirstResponder])
    {
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        
        NSString *textFieldDateString2=[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]];

        NSDate *date1 = [dateFormatter dateFromString:FromDateTxt.text];
        NSDate *date2 = [dateFormatter dateFromString:textFieldDateString2];
        
        if ([date1 compare:date2] == NSOrderedDescending) {
            NSLog(@"date1 is later than date2");
            
            
            UIAlertController * alert = [UIAlertController
                                         alertControllerWithTitle:@"Warning"
                                         message:@"Please select a correct date"
                                         preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* yesButton = [UIAlertAction
                                        actionWithTitle:@"Ok"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {
                                            //Handle your yes please button action here
                                        }];
            
            
            [alert addAction:yesButton];
            [self presentViewController:alert animated:YES completion:nil];
        } else if ([date1 compare:date2] == NSOrderedAscending)
        {
            NSLog(@"date1 is earlier than date2");
            ToDateTxt.text=textFieldDateString2;
            
        } else {
            NSLog(@"dates are the same");
            
            
            UIAlertController * alert = [UIAlertController
                                         alertControllerWithTitle:@"Warning"
                                         message:@"Please select a correct date"
                                         preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* yesButton = [UIAlertAction
                                        actionWithTitle:@"Ok"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {
                                            //Handle your yes please button action here
                                        }];
            
            
            [alert addAction:yesButton];
            [self presentViewController:alert animated:YES completion:nil];
        }
        [ToDateTxt resignFirstResponder];
    }
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (tableView==MyEntryDisplayTableView) {
         totalScetions =[ProjectName count];//first get total rows in that section by current indexPath.

        return [PrName count];
    }
    else{
        return 1;
    }
}

- (NSInteger)tableView:(UITableView *)theTableView numberOfRowsInSection:(NSInteger)section
{
    if (theTableView==dropDownTableView) {
        return [typeArray count];
    }
    else if (theTableView==dropDownTableView1) {
    return [ProjectName count];
    }
    else if (theTableView==MyEntryDisplayTableView)
    {
        return 1;
    }
    return nil;
    }

// the cell will be returned to the tableView
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView==dropDownTableView) {
        static NSString *cellIdentifier = @"cellID";
        
        UITableViewCell *cell = [dropDownTableView dequeueReusableCellWithIdentifier:
                                 cellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:
                    UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.textLabel.font=[UIFont fontWithName:@"Arial" size:14];

        cell.textLabel.text=[typeArray objectAtIndex:indexPath.row];
        
        return cell;
        
    }
    else if (tableView==dropDownTableView1)
    {
        static NSString *cellIdentifier = @"cellID";
        
        UITableViewCell *cell = [dropDownTableView1 dequeueReusableCellWithIdentifier:
                                 cellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:
                    UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.textLabel.font=[UIFont fontWithName:@"Arial" size:14];
        
        cell.textLabel.text=[ProjectName objectAtIndex:indexPath.row];
        
        return cell;
    }
    else if (tableView==MyEntryDisplayTableView)
    {
        static NSString *simpleTableIdentifier = @"MyEntryTableViewCell";
        
        MyEntryTableViewCell*cell = (MyEntryTableViewCell*)[MyEntryDisplayTableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MyEntryTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            cell.ProJectNameOutlet.text=[PrName objectAtIndex:indexPath.section];
            cell.ProjectCodeOutlet.text=[PrCode objectAtIndex:indexPath.section];
            cell.DateOutlet.text=[PrDate objectAtIndex:indexPath.section];
            cell.HourLabelOutlet.text=[Hour objectAtIndex:indexPath.section];
            cell.layer.cornerRadius=5;
            cell.layer.borderWidth=1.5;
            [[cell layer] setBorderColor:[UIColor lightGrayColor].CGColor];
            
            NSInteger sectionsAmount = [tableView numberOfSections];

            if(indexPath.section ==sectionsAmount-1){
                //this is the last row in section.
                UIView* view1 = [[UIView alloc] initWithFrame:CGRectMake(0,cell.frame.origin.y+60,self.view.frame.size.width/2.0f,40.0f)];
                view1.backgroundColor = [UIColor redColor];
                [cell addSubview:view1];
                UILabel *Label1=[[UILabel alloc]init];
                Label1.text=@"Grand Total:";
                Label1.frame=CGRectMake(20,10,90,20);
                Label1.textColor=[UIColor whiteColor];
                [Label1 setFont:[UIFont boldSystemFontOfSize:12]];
                [view1 addSubview:Label1];
                UILabel *GrandToal=[[UILabel alloc]init];
                GrandToal.text=GrantTotalString;
                GrandToal.frame=CGRectMake(Label1.frame.origin.x+74,10,40,20);
                GrandToal.textColor=[UIColor whiteColor];
                [GrandToal setFont:[UIFont boldSystemFontOfSize:12]];
                [view1 addSubview:GrandToal];
                cell.indentationLevel = 2;

                



            }
            else
            {
                
            }
            
        }
        return cell;
    }
    return nil;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView==dropDownTableView) {
        DropdownTxtOutlet.text=[typeArray objectAtIndex:indexPath.row];
        [dropDownTableView removeFromSuperview];
    }
    else if (tableView==dropDownTableView1)
    {
        Dropdown1TxtOutlet.text=[ProjectName objectAtIndex:indexPath.row];
        [dropDownTableView1 removeFromSuperview];

    }
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (tableView==MyEntryDisplayTableView) {
        return 55;
    }
    else{
        return 44;
        
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 3; // you can have your own choice, of course
}


@end
