//
//  ConsultantViewController.m
//  Timesheet
//
//  Created by electra on 1/24/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import "ConsultantViewController.h"

@interface ConsultantViewController ()
{
    UIActivityIndicatorView *activity;
}

@end

@implementation ConsultantViewController
@synthesize AddButtonOutlet,ConsultantTxtOutlet,ProjectNameTxtOutlet,DisplayTableOutlet,ArrowImg1,ArrowImg2;

- (void)viewDidLoad {
    [super viewDidLoad];
    AddButtonOutlet.layer.cornerRadius=3;
    AddButtonOutlet.layer.borderWidth=1.5;
    [[AddButtonOutlet layer] setBorderColor:[UIColor whiteColor].CGColor];
    dropDownTableView=[[UITableView alloc]init];
    dropDownTableView1=[[UITableView alloc]init];
    dropDownTableView.delegate=self;
    dropDownTableView.dataSource=self;
    dropDownTableView1.delegate=self;
    dropDownTableView1.dataSource=self;
    ProjectNameArray=[[NSMutableArray alloc]init];
    [self FunctionCalling];
    [ProjectNameTxtOutlet addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    [ConsultantTxtOutlet addTarget:self action:@selector(textFieldDidChange11:) forControlEvents:UIControlEventEditingChanged];
    DisplayArray=[[NSMutableArray alloc]init];
    prjArray=[[NSMutableArray alloc]init];
    InputArray=[[NSMutableArray alloc]init];
    o1=[[NSMutableDictionary alloc]init];
    UIView *Drop=[[UIView alloc]init];
    Drop.backgroundColor=[UIColor blackColor];
    ConsultantTxtOutlet.rightViewMode = UITextFieldViewModeAlways;
    ConsultantTxtOutlet.rightView =Drop;
    activity = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    activity.frame = CGRectMake(round((self.view.frame.size.width - 25) / 2), round((self.view.frame.size.height - 25) / 2), 25, 25);
    [ArrowImg1 setImage:[UIImage imageNamed:@"dn.png"]];
    [ArrowImg2 setImage:[UIImage imageNamed:@"dn.png"]];


}
-(void)viewWillAppear:(BOOL)animated
{
    [self FunctionCalling1];

}
-(void)FunctionCalling1
{

    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MGet_AssignConsultant_UserList"]];
    
    
    //create the Method "GET" or "POST"
    [request setHTTPMethod:@"POST"];
    
    //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
    
    
    //Check The Value what we passed
   // NSLog(@"the data Details is =%@", userUpdate);
    
    //Convert the String to Data
    //NSData *data1 = [userUpdate dataUsingEncoding:NSUTF8StringEncoding];
    
    //Apply the data to the body
    //[request setHTTPBody:data1];
    // [request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
    NSURLSessionDataTask *task =
    [[NSURLSession sharedSession] dataTaskWithRequest:request
                                    completionHandler:^(NSData *data,
                                                        NSURLResponse *response,
                                                        NSError *error) {
                                        
                                        NSString *resSrt = [[NSString alloc]initWithData:data encoding:NSASCIIStringEncoding];
                                        NSLog(@"%@",resSrt);
                                        NSError *e = nil;
                                        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&e];
                                        NSLog(@"%@", json);
                                        ConsultantArray=[json valueForKey:@"UserName"];
                                        NoConId=[json valueForKey:@"UserId"];

                                        // Code to run when the response completes...
                                    }];
    [task resume];
        
        

    
     
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
-(void)FunctionCalling
{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MGet_AssignConsultant_AllProjectList"]];
    
    
    //create the Method "GET" or "POST"
    [request setHTTPMethod:@"POST"];
    
    //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
    NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput={'sDBName' : 'ABEO_INTL'}"];
    
    
    
    //Check The Value what we passed
    NSLog(@"the data Details is =%@", userUpdate);
    
    //Convert the String to Data
    NSData *data1 = [userUpdate dataUsingEncoding:NSUTF8StringEncoding];
    [request setValue:@"length" forHTTPHeaderField:@"Content-Length"];

    //Apply the data to the body
    [request setHTTPBody:data1];
    NSURLSessionDataTask *task =
    [[NSURLSession sharedSession] dataTaskWithRequest:request
                                    completionHandler:^(NSData *data,
                                                        NSURLResponse *response,
                                                        NSError *error) {
                                        
                                        NSString *resSrt = [[NSString alloc]initWithData:data encoding:NSASCIIStringEncoding];
                                        NSLog(@"got response==%@", resSrt);
                                        
                                        
                                        NSError *e = nil;
                                        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&e];
                                        NSLog(@"%@", json);
                                        ProjectNameArray=[json valueForKey:@"PrjName"];
                                        ProjectCodeArray=[json valueForKey:@"ProjectCodeOnly"];
                                        
                                        NSLog(@"\n%@",ProjectCodeArray);
                                        // Code to run when the response completes...
                                    }];
    [task resume];
   }
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField==ProjectNameTxtOutlet) {
        [activity startAnimating];
      dropDownTableView.frame=CGRectMake(30,ProjectNameTxtOutlet.frame.origin.y+32,self.view.frame.size.width/1.2,self.view.frame.size.height/2.5);
        dropDownTableView.layer.cornerRadius=5;
        //[dropDownTableView style:(UITableViewStylePlain)];
        dropDownTableView.scrollEnabled=YES;
        dropDownTableView.hidden=YES;
        dropDownTableView.backgroundColor=[UIColor lightGrayColor];
        [self.view addSubview:dropDownTableView];
        [activity stopAnimating];
        
    }
    else if (textField==ConsultantTxtOutlet)
    {
                    ConsultantTxtOutlet.userInteractionEnabled=YES;
            dropDownTableView1.frame=CGRectMake(ConsultantTxtOutlet.frame.origin.x,ConsultantTxtOutlet.frame.origin.y+30,ConsultantTxtOutlet.frame.size.width,self.view.frame.size.height/4);
            //[dropDownTableView style:(UITableViewStylePlain)];
            dropDownTableView1.backgroundColor=[UIColor lightGrayColor];
            dropDownTableView.layer.cornerRadius=5;
            
            
            dropDownTableView1.scrollEnabled=YES;
            dropDownTableView1.hidden=YES;
            
            [self.view addSubview:dropDownTableView1];

        

    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==ProjectNameTxtOutlet) {
        [textField resignFirstResponder];
        dropDownTableView.hidden = YES;
        
        return YES;

    }
    else if (textField==ConsultantTxtOutlet)
    {
        [textField resignFirstResponder];
        dropDownTableView1.hidden = YES;
        
        return YES;
    }
    return nil;
}
-(void)textFieldDidChange:(UITextField*)textField
{
    dropDownTableView.hidden=NO;
    NSString *searchText =ProjectNameTxtOutlet.text;
    NSPredicate *p = [NSPredicate predicateWithFormat:@"SELF CONTAINS[cd] %@",searchText];
    searchArray = [ProjectNameArray filteredArrayUsingPredicate:p];
    NSLog(@"HERE %@",searchArray);
    [dropDownTableView reloadData];
}
-(void)textFieldDidChange11:(UITextField*)textField
{
    dropDownTableView1.hidden=NO;
    NSString *searchText =ConsultantTxtOutlet.text;
    NSPredicate *p = [NSPredicate predicateWithFormat:@"SELF CONTAINS[cd] %@",searchText];
    SearchArray1 = [ConsultantArray filteredArrayUsingPredicate:p];
    NSLog(@"HERE %@",searchArray);
    [dropDownTableView1 reloadData];
}

- (void)searchAutocompleteEntriesWithSubstring:(NSString *)substring {
    
    // Put anything that starts with this substring into the autocompleteUrls array
    // The items in this array is what will show up in the table view
    [searchArray removeAllObjects];
    for(NSString *curString in ProjectNameArray) {
        //NSRange substringRange = [curString rangeOfString:substring];
        
        if ([curString rangeOfString:substring options:NSCaseInsensitiveSearch].location != NSNotFound) {
            [searchArray addObject:curString];
        }
    }
    [dropDownTableView reloadData];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma tableview delegate methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView==dropDownTableView) {
        return [searchArray count];
    }
    if (tableView==dropDownTableView1) {
        return [SearchArray1 count];
    }
    else
    {
        return [DisplayArray count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIView *bgColorView = [[UIView alloc] init];
   
    if (tableView==dropDownTableView) {
        [activity startAnimating];
        static NSString *simpleTableIdentifier = @"SimpleTableItem";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
        }
        cell.backgroundColor=[UIColor darkGrayColor];
        cell.textLabel.font = [UIFont systemFontOfSize:([UIFont systemFontSize]-5)];
        //dropDownTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        cell.textLabel.text =[searchArray objectAtIndex:indexPath.row];
        cell.textLabel.textAlignment=NSTextAlignmentCenter;
        cell.textLabel.textColor=[UIColor whiteColor];
        bgColorView.backgroundColor = [UIColor blueColor];
        [cell setSelectedBackgroundView:bgColorView];
        
        [activity stopAnimating];
        return cell;

    }
    else if (tableView==dropDownTableView1)
    {    static NSString *simpleTableIdentifier1 = @"SimpleTableItem";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier1];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier1];
        }
        cell.backgroundColor=[UIColor darkGrayColor];
        cell.textLabel.textAlignment=NSTextAlignmentCenter;
        cell.textLabel.textColor=[UIColor whiteColor];
        cell.textLabel.text =[SearchArray1 objectAtIndex:indexPath.row];
        dropDownTableView1.separatorStyle = UITableViewCellSeparatorStyleNone;

        return cell;
        
    }
    else if (tableView==DisplayTableOutlet)
    {
        static NSString *simpleTableIdentifier = @"ConsultantTableViewCell";
        
        ConsultantTableViewCell*cell = (ConsultantTableViewCell *)[DisplayTableOutlet dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ConsultantTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            cell.SnoLabelOutlet.text = [NSString stringWithFormat:@"%i", indexPath.row+1];
            cell.ProjectNameOutlet.text=[DisplayArray objectAtIndex:indexPath.row];
            cell.layer.cornerRadius=5;
            cell.layer.borderWidth=1.5;
            [[cell layer] setBorderColor:[UIColor lightGrayColor].CGColor];
            [DisplayTableOutlet setEditing:YES];
            [cell setClipsToBounds:NO];
        }
        return cell;
 
    }
    return nil;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (tableView==dropDownTableView) {
        [ArrowImg1 setImage:[UIImage imageNamed:@""]];

        UITableViewCell *selectedCell = [tableView cellForRowAtIndexPath:indexPath];
        NSString *cellText = selectedCell.textLabel.text;
        int muni = [ProjectNameArray indexOfObject:cellText];
        NSLog(@"%d",muni);
        
        //akinternetngc@gmail.com

        ProjectNameTxtOutlet.text=cellText;
        [dropDownTableView removeFromSuperview];
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MGet_AssignConsultant_GetExistingRecord"]];
        
        
        //create the Method "GET" or "POST"
        [request setHTTPMethod:@"POST"];
        prjString=[ProjectCodeArray objectAtIndex:muni];
        //prjString=[NSString stringWithFormat:@""%@"",prjString];
        AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
        SaveString = appDelegate.UserIdString;
        //UserId=[NSString stringWithFormat:@"'%@'",SaveString];

        NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput= {'ProjectCode':%@,'ProjectManagerId':%@ }",prjString,SaveString];

        //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
        
        
        //Check The Value what we passed
        // NSLog(@"the data Details is =%@", userUpdate);
        
        //Convert the String to Data
        NSData *data1 = [userUpdate dataUsingEncoding:NSUTF8StringEncoding];
        
        //Apply the data to the body
        [request setHTTPBody:data1];
        
        NSURLSessionDataTask *task =
        [[NSURLSession sharedSession] dataTaskWithRequest:request
                                        completionHandler:^(NSData *data,
                                                            NSURLResponse *response,
                                                            NSError *error) {
                                            
                                            NSString *resSrt = [[NSString alloc]initWithData:data encoding:NSASCIIStringEncoding];
                                            NSLog(@"got response==%@", resSrt);
                                            
                                            
                                            NSError *e = nil;
                                            NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&e];
                                            NSLog(@"%@", json);
                                            
                                            NSMutableArray *UsernameArray=[[NSMutableArray alloc]init];
                                            UsernameArray=[[json valueForKey:@"UserName"]objectAtIndex:0];
                                            NSLog(@"%@",DisplayArray);
                                                                                    // Code to run when the response completes...
                                        }];
        [task resume];

        [ProjectNameTxtOutlet resignFirstResponder];
        /*
        // [request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
        [request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
        NSError *err;
        NSURLResponse *response;
        
        NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
        
        NSString *resSrt = [[NSString alloc]initWithData:responseData encoding:NSASCIIStringEncoding];
        NSLog(@"got response==%@", resSrt);
        NSError *e = nil;
       //DisplayArray=[json valueforkey:@"UserName"];
        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&e];
        NSLog(@"%@", json);
        NSMutableArray *UsernameArray=[[NSMutableArray alloc]init];
        UsernameArray=[[json valueForKey:@"UserName"]objectAtIndex:0];
        NSLog(@"%@",DisplayArray);
        
*/
        
    }
    else if (tableView==dropDownTableView1)
    {
        [ArrowImg2 setImage:[UIImage imageNamed:@""]];

        UITableViewCell *selectedCell = [tableView cellForRowAtIndexPath:indexPath];
        NSString *cellText = selectedCell.textLabel.text;
        ConsultantTxtOutlet.text=cellText;
        int muni = [ConsultantArray indexOfObject:ConsultantTxtOutlet.text];
        ConIdString=[NoConId objectAtIndex:muni];
        

        

        [dropDownTableView1 removeFromSuperview];
    }
}

- (IBAction)AddButtonTapped:(id)sender {
    [ConsultantTxtOutlet resignFirstResponder];
    
    if ([ConsultantTxtOutlet.text isEqualToString:@""]) {
        
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Warning"
                                     message:@"Please select the fields"
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* yesButton = [UIAlertAction
                                    actionWithTitle:@"Ok"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        //Handle your yes please button action here
                                    }];
        
        [alert addAction:yesButton];
        
        [self presentViewController:alert animated:YES completion:nil];

        
    }
    else
    {
        AddButtonOutlet.enabled=YES;
        DisplayTableOutlet.delegate=self;
        DisplayTableOutlet.dataSource=self;
        NSString *arrString=ConsultantTxtOutlet.text;
        NSDate *currDate = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
        [dateFormatter setDateFormat:@"YYYY-MM-dd"];
        NSString *dateString = [dateFormatter stringFromDate:currDate];
        NSLog(@"%@",dateString);

        

        jsonStr = [NSString stringWithFormat:@"{\"ProjectCode\":\"%@\",\"ProjectManagerId\":\"%@\",\"UserId\":\"%@\", \"CreatedDate\":\"%@\"}",prjString,SaveString,ConIdString,dateString];
        
        [InputArray addObject:jsonStr];
        
        
    
        NSLog(@"%@",InputArray);
       

        if ([DisplayArray containsObject:arrString]) {
            
        }
        else
        {
            [DisplayArray addObject:arrString];
            [DisplayTableOutlet reloadData];
            ConsultantTxtOutlet.text=@"";
            NSLog(@"%@",DisplayArray);
        }
    }
    
    
}

- (IBAction)LogoutButtonTapped:(id)sender {
    UIAlertController * alert = [UIAlertController
                                 alertControllerWithTitle:@"Confirmation"
                                 message:@"Are you sure you want to Logout"
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* yesButton = [UIAlertAction
                                actionWithTitle:@"Yes"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action) {
                                    
                                    
                                    
                                    
                                    //Handle your yes please button action here
                                }];
    
    UIAlertAction* noButton = [UIAlertAction
                               actionWithTitle:@"Cancel"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction * action) {
                                   //Handle no, thanks button
                               }];
    
    [alert addAction:yesButton];
    [alert addAction:noButton];
    
    [self presentViewController:alert animated:YES completion:nil];
    
}

- (IBAction)BackButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)SaveButtonTapped:(id)sender {
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MSave_AssignConsultant"]];
    
    
    //create the Method "GET" or "POST"
    NSError *error;
    [request setHTTPMethod:@"POST"];
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:InputArray options:NSJSONWritingPrettyPrinted error:&error];
   // NSData *jsonData = [NSJSONSerialization dataWithJSONObject:InputArray options:0 error:&error];

    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
   // jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    jsonString=[jsonString stringByReplacingOccurrencesOfString:@"\\" withString:@""];

   jsonString1=[NSString stringWithFormat:@"sJsonInput=%@",jsonString];
    //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
   // NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput={'sDBName' : 'ABEO_INTL'}"];
    
    
    
    //Check The Value what we passed
   // NSLog(@"the data Details is =%@", userUpdate);
    
    //Convert the String to Data
    NSData *data1 = [jsonString1 dataUsingEncoding:NSUTF8StringEncoding];
    [request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
    NSLog(@"%@",InputArray);
    
    //Apply the data to the body
    [request setHTTPBody:data1];
    NSURLSessionDataTask *task =
    [[NSURLSession sharedSession] dataTaskWithRequest:request
                                    completionHandler:^(NSData *data,
                                                        NSURLResponse *response,
                                                        NSError *error) {
                                        
                                        NSString *resSrt = [[NSString alloc]initWithData:data encoding:NSASCIIStringEncoding];
                                        NSLog(@"got response==%@", resSrt);
                                        
                                        
                                        NSError *e = nil;
                                        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&e];
                                        NSLog(@"%@", json);
                                        NSString *ResultString=[[json valueForKey:@"Result"]objectAtIndex:0];
                                        if ([ResultString isEqualToString:@"Success"]) {
                                            UIAlertController * alert = [UIAlertController
                                                                         alertControllerWithTitle:@"Success"
                                                                         message:@"Consultant has been Assigned Successfully"
                                                                         preferredStyle:UIAlertControllerStyleAlert];
                                            
                                            UIAlertAction* yesButton = [UIAlertAction
                                                                        actionWithTitle:@"Ok"
                                                                        style:UIAlertActionStyleDefault
                                                                        handler:^(UIAlertAction * action) {
                                                                            //Handle your yes please button action here
                                                                        }];
                                            
                                            
                                            [alert addAction:yesButton];
                                            
                                            [self presentViewController:alert animated:YES completion:nil];
                                            
                                        }
                                        else{
                                            
                                        }
                                        
                                        NSLog(@"\n%@",ProjectCodeArray);
                                        // Code to run when the response completes...
                                    }];
    [task resume];
}

- (IBAction)ClearButtonTapped:(id)sender {
    NSLog(@"%@",DisplayArray);
    ConsultantTxtOutlet.text=@"";
    ProjectNameTxtOutlet.text=@"";
    [DisplayArray removeAllObjects];
    [DisplayTableOutlet reloadData];
    [ArrowImg1 setImage:[UIImage imageNamed:@"dn.png"]];
    [ArrowImg2 setImage:[UIImage imageNamed:@"dn.png"]];

    
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
        [DisplayArray removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [DisplayTableOutlet reloadData];
    NSLog(@"%@",InputArray);
    
    //49913203
    //230110100056732
}
@end
