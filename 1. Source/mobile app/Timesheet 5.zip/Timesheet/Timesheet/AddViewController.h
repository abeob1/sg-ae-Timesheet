//
//  AddViewController.h
//  Timesheet
//
//  Created by electra on 1/11/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchTableViewCell.h"
#import "WeeklyViewController.h"

@interface AddViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *TableViewOutlet;
@property(strong,nonatomic)NSMutableArray *TableArray;
//@property(strong,nonatomic)WeeklyViewController *ViewController1;
//@property(retain,nonatomic)WeeklyViewController *Vie1;

@end
