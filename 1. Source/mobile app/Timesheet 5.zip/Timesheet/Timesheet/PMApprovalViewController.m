//
//  PMApprovalViewController.m
//  Timesheet
//
//  Created by electra on 1/17/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import "PMApprovalViewController.h"

@interface PMApprovalViewController ()

@end

@implementation PMApprovalViewController
@synthesize SelectButtonOutlet,MainTableViewOutlet,FilterButtonOutlet,FromDateTxtOutlet,ToDateTxtOutlet,DropDownTxtOutlet,DropDownTxt2Outlet,UnderView,NodataFoundLabelOutlet;

- (void)viewDidLoad {
    [super viewDidLoad];
    ///corner radius for oulets///////////////
    FilterButtonOutlet.layer.cornerRadius=3;
    FilterButtonOutlet.layer.borderWidth=1.5;
    [[FilterButtonOutlet layer] setBorderColor:[UIColor whiteColor].CGColor];
    SelectButtonOutlet.layer.borderWidth=2;
    [[SelectButtonOutlet layer] setBorderColor:[UIColor blackColor].CGColor];
    datePicker = [[UIDatePicker alloc]init];
    datePicker.datePickerMode = UIDatePickerModeDate;
    toolBar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,35)];
    [toolBar setTintColor:[UIColor grayColor]];
    UIBarButtonItem *doneBtn = [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(ShowSelectedDate)];
    UIBarButtonItem *space = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [toolBar setItems:[NSArray arrayWithObjects:space,doneBtn, nil]];
    
    dropDownTableView =[[UITableView alloc]init];
    // must set delegate & dataSource, otherwise the the table will be empty and not responsive
    dropDownTableView.delegate = self;
    dropDownTableView.dataSource = self;
    
    dropDownTableView.backgroundColor = [UIColor cyanColor];
    
    sArray=[[NSMutableArray alloc]initWithObjects:@"Pending",@"Approved",@"All",nil];
    MainTableViewOutlet.hidden=YES;
    UnderView.hidden=YES;


    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma tableview delegate methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (tableView==dropDownTableView) {
        return 1;
    }
    else if (tableView==MainTableViewOutlet)
    {
    return 5; //one male and other female
    }
   else
   {
       return 1;
       
   }
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView==dropDownTableView) {
        return [UserNameArray count];
    }
    else if (tableView==MainTableViewOutlet)
    {
    return 1;
    }
    else
    {
        return [sArray count];
    }
    return nil;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView==dropDownTableView) {
        static NSString *simpleTableIdentifier = @"SimpleTableItem";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
        }
        
        cell.textLabel.text = [UserNameArray objectAtIndex:indexPath.row];
        return cell;
    }
    else if (tableView==MainTableViewOutlet)
    {
    static NSString *simpleTableIdentifier = @"PendingTableViewCell";
    
    PendingTableViewCell*cell = (PendingTableViewCell *)[MainTableViewOutlet dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"PendingTableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
       // cell.MenuLabelOutlet.text=[MenuTableItemArray objectAtIndex:indexPath.section];
       // cell.MenuTableImgOutlet.image=[UIImage imageNamed:[MenuTableImgArray objectAtIndex:indexPath.section]];
        //cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.CheckButtonOutlet.layer.borderWidth=2;
        [[cell.CheckButtonOutlet layer] setBorderColor:[UIColor blackColor].CGColor];
         cell.layer.cornerRadius=5;
        cell.layer.borderWidth=1.5;
        [[cell layer] setBorderColor:[UIColor lightGrayColor].CGColor];
        
    }
    return cell;
    }
    else
    {
        static NSString *simpleTableIdentifier = @"SimpleTableItem";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
        }
        
        cell.textLabel.text = [sArray objectAtIndex:indexPath.row];
        return cell;

    }
    return nil;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView==MainTableViewOutlet) {
        return 55;

    }
    else
    {
        return 40;

    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 5.; // you can have your own choice, of course
}
- (void)tableView:(UITableView *)TableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (TableView==MainTableViewOutlet) {
        NSLog(@"main");
    }
    else if (TableView==dropDownTableView)
    {
        int row=indexPath.row;
        DropDownTxtOutlet.text=[UserNameArray objectAtIndex:row];
        UserIdString=[UserIdArray objectAtIndex:row];
        [dropDownTableView removeFromSuperview];
    }
    else
    {
        
        int row1=indexPath.row;
        DropDownTxt2Outlet.text=[sArray objectAtIndex:row1];
        [dropDownTableView2 removeFromSuperview];
    }
}

- (IBAction)DatePickerButton1Tapped:(id)sender {
    NSLog(@"%@",FromDateTxtOutlet.text);
    NSString *str=FromDateTxtOutlet.text;
    if ([str isEqualToString:@""]) {
        
        
        dispatch_async(dispatch_get_current_queue(), ^{
            [FromDateTxtOutlet becomeFirstResponder];
        });
        FromDateTxtOutlet.inputView=datePicker;
    }
    else
    {
        FromDateTxtOutlet.text=@"";
}
}

- (IBAction)DatePickerButton2Tapped:(id)sender {
    NSLog(@"%@",FromDateTxtOutlet.text);
    NSString *str=ToDateTxtOutlet.text;
    if ([str isEqualToString:@""]) {
        
        
        dispatch_async(dispatch_get_current_queue(), ^{
            [ToDateTxtOutlet becomeFirstResponder];
        });
        ToDateTxtOutlet.inputView=datePicker;
    }
    else
    {
        ToDateTxtOutlet.text=@"";
    }

}

- (IBAction)BackButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)ApproveButtonTapped:(id)sender {
}

- (IBAction)RejectButtonTapped:(id)sender {
}

- (IBAction)FilterButtonTapped:(id)sender {
    
    
    
    NSURL *url = [NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MGet_FilterPMApproval"];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    NSString *SaveString = appDelegate.UserName;
    NSString *fromString=[FromDateTxtOutlet.text stringByReplacingOccurrencesOfString:@"-" withString:@""];
    NSString *ToString=[ToDateTxtOutlet.text stringByReplacingOccurrencesOfString:@"-" withString:@""];
    NSString *ProjectManagerString=DropDownTxtOutlet.text;

    if ([DropDownTxt2Outlet.text isEqualToString:@"Pending"]) {
        Status1=@"2";

    }
    else if ([DropDownTxt2Outlet.text isEqualToString:@"Approved"])
    {
        Status1=@"1";

    }
    else
    {
        Status1=@"0";

    }
    
    
    NSDictionary *o1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:fromString, @"sIN_BeginDate",ToString, @"sIN_EndDate",ProjectManagerString,@"sIN_ProjectManager",UserIdString,@"sIN_UserCode",Status1,@"sIN_Status",nil];
    //FilterInputArray=[NSMutableArray arrayWithObject:o1];
    //create the Method "GET" or "POST"
    NSError *error;
    [request setHTTPMethod:@"POST"];
    NSMutableArray *InputArray=[[NSMutableArray alloc]init];
    [InputArray addObject:o1];
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:InputArray options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *jsonString1=[NSString stringWithFormat:@"sJsonInput=%@",jsonString];
    NSData *data1 = [jsonString1 dataUsingEncoding:NSUTF8StringEncoding];
    
    //Apply the data to the body
    [request setHTTPBody:data1];
    NSError *err;
    NSURLResponse *response;
    
    NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
    
    NSString *resSrt = [[NSString alloc]initWithData:responseData encoding:NSASCIIStringEncoding];
    NSLog(@"got response==%@", resSrt);
    if(resSrt)
    {
        NSLog(@"got response");
    }
    else
    {
        NSLog(@"faield to connect");
    }
    
    NSError *e = nil;
    NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&e];
    
    if ([json count]==0) {
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Warning"
                                     message:@"No Records Found"
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* yesButton = [UIAlertAction
                                    actionWithTitle:@"ok"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        
                                        
                                        
                                        
                                        //Handle your yes please button action here
                                    }];
        
        
        [alert addAction:yesButton];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    else
    {
    
    MainTableViewOutlet.dataSource=self;
    MainTableViewOutlet.delegate=self;
        
    
    }

}
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField==DropDownTxtOutlet) {
        if ([FromDateTxtOutlet.text isEqualToString:@""]||[ToDateTxtOutlet.text isEqualToString:@""]) {
            
        }
        else
        {
        NSLog(@"clicked");
        
        
        NSURL *url = [NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MGet_PMApproval_UserList"];
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
        AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
        NSString *SaveString = appDelegate.UserName;
            NSString *fromString=[FromDateTxtOutlet.text stringByReplacingOccurrencesOfString:@"-" withString:@""];
             NSString *ToString=[ToDateTxtOutlet.text stringByReplacingOccurrencesOfString:@"-" withString:@""];
        
        NSDictionary *o1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:fromString, @"sFromDate",ToString, @"sToDate",SaveString,@"sUserCode",nil];
        //FilterInputArray=[NSMutableArray arrayWithObject:o1];
        //create the Method "GET" or "POST"
        NSError *error;
        [request setHTTPMethod:@"POST"];
            NSMutableArray *InputArray=[[NSMutableArray alloc]init];
            [InputArray addObject:o1];

        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:InputArray options:NSJSONWritingPrettyPrinted error:&error];
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSString *jsonString1=[NSString stringWithFormat:@"sJsonInput=%@",jsonString];
            NSData *data1 = [jsonString1 dataUsingEncoding:NSUTF8StringEncoding];
            
            //Apply the data to the body
            [request setHTTPBody:data1];
            NSError *err;
            NSURLResponse *response;
            
            NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
            
            NSString *resSrt = [[NSString alloc]initWithData:responseData encoding:NSASCIIStringEncoding];
            NSLog(@"got response==%@", resSrt);
            if(resSrt)
            {
                NSLog(@"got response");
            }
            else
            {
                NSLog(@"faield to connect");
            }
            
            NSError *e = nil;
            NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&e];
            UserNameArray=[[NSMutableArray alloc]init];
            UserIdArray=[[NSMutableArray alloc]init];
            UserNameArray=[json valueForKey:@"UserName"];
            UserIdArray=[json valueForKey:@"UserId"];

            
                    //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
        // NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput={'sDBName' : 'ABEO_INTL'}"];
        
        
        
        //Check The Value what we passed
        // NSLog(@"the data Details is =%@", userUpdate);
        
        //Convert the String to Data
            /*
        NSData *data1 = [jsonString1 dataUsingEncoding:NSUTF8StringEncoding];
        [request setHTTPBody:data1];
        // [request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
        [request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
            NSURLSessionDataTask *task =
            [[NSURLSession sharedSession] dataTaskWithRequest:request
                                            completionHandler:^(NSData *data,
                                                                NSURLResponse *response,
                                                                NSError *error) {
                                                
                                                NSString *resSrt = [[NSString alloc]initWithData:data encoding:NSASCIIStringEncoding];
                                                NSLog(@"got response==%@", resSrt);
                                                NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                                                NSLog(@"%@", json);

                                                // Code to run when the response completes...
                                            }];
            [task resume];
       
        
        
        */
        
        // add to canvas
dropDownTableView.frame=CGRectMake(DropDownTxtOutlet.frame.origin.x,DropDownTxtOutlet.frame.origin.y+30,DropDownTxtOutlet.frame.size.width,self.view.frame.size.height/4);
        //[dropDownTableView style:(UITableViewStylePlain)];
        [self.view addSubview:dropDownTableView];
        
        
        }
        

        
    }
    else if (textField==DropDownTxt2Outlet)
    {
    NSLog(@"clicked");
    
        [dropDownTableView2=[UITableView alloc]init];
dropDownTableView2.frame=CGRectMake(DropDownTxt2Outlet.frame.origin.x,DropDownTxt2Outlet.frame.origin.y+30,DropDownTxt2Outlet.frame.size.width,self.view.frame.size.height/4);
        [dropDownTableView2 setBackgroundColor:[UIColor redColor]];
        [self.view addSubview:dropDownTableView2];
        dropDownTableView2.delegate=self;
        dropDownTableView2.dataSource=self;
    }
    
    else if (textField==FromDateTxtOutlet)
    {
        [FromDateTxtOutlet setInputView:datePicker];
        [FromDateTxtOutlet setInputAccessoryView:toolBar];


    }
    else if (textField==ToDateTxtOutlet)
    {
        [ToDateTxtOutlet setInputView:datePicker];
        [ToDateTxtOutlet setInputAccessoryView:toolBar];
    }
       
}
-(void)ShowSelectedDate
{
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"YYYY-MM-dd"];
    if ([FromDateTxtOutlet isFirstResponder])
    {
        FromDateTxtOutlet.text=[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]];
        [FromDateTxtOutlet resignFirstResponder];
    }
    else if ([ToDateTxtOutlet resignFirstResponder])
    {
        ToDateTxtOutlet.text=[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]];
        [ToDateTxtOutlet resignFirstResponder];
    }
}
@end
