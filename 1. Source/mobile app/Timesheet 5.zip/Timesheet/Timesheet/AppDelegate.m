//
//  AppDelegate.m
//  Timesheet
//
//  Created by electra on 1/10/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate
{
    NSString *requestReply;
    MenuViewController * MenuVC;
}
@synthesize PassArray,UserIdString,DbName,UserName,PassImgArray;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    NSURL *scriptUrl = [NSURL URLWithString:@"http://www.google.com/m"];
    NSData *data = [NSData dataWithContentsOfURL:scriptUrl];
    if (data)
    {
        NSLog(@"Device is connected to the Internet");
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MGet_ValidateUser"]];
        
        
        //create the Method "GET" or "POST"
        [request setHTTPMethod:@"POST"];
        
        //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
        NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput={'sIMEINo' :'002ebf12-a125-5ddf-a739-67c3c5d20188'}"];
        
        
        
        //Check The Value what we passed
        NSLog(@"the data Details is =%@", userUpdate);
        
        //Convert the String to Data
        NSData *data1 = [userUpdate dataUsingEncoding:NSUTF8StringEncoding];
        
        //Apply the data to the body
        [request setHTTPBody:data1];
        // [request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
        [request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
        
        //Create the response and Error
        NSError *err;
        NSURLResponse *response;
        
        NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
        
        NSString *resSrt = [[NSString alloc]initWithData:responseData encoding:NSASCIIStringEncoding];
        NSLog(@"got response==%@", resSrt);
        if(resSrt)
        {
            NSLog(@"got response");
        }
        else
        {
            NSLog(@"faield to connect");
        }
        
        NSError *e = nil;
        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&e];
        NSLog(@"%@", json);
        // BOOL mine=[json objectAtIndex:]
        NSString *CompareString=[[json valueForKey:@"IsPM"]objectAtIndex:0];
        NSString *LoginStatus=[[json valueForKey:@"Status"]objectAtIndex:0];
        DbName=[[json valueForKey:@"DBName"]objectAtIndex:0];
        UserName=[[json valueForKey:@"UserName"]objectAtIndex:0];
        NSLog(@"%@",CompareString);
        //UIView *LoginSucessView=[[UIView alloc]initWithFrame:CGRectMake(0,0,, <#CGFloat height#>)
        if ([LoginStatus isEqualToString:@"Login Successful"]) {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Login" message:@"Login Sucessed" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            UIWindow *alertWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
            alertWindow.rootViewController = [[UIViewController alloc] init];
            alertWindow.windowLevel = UIWindowLevelAlert + 1;
            [alertWindow makeKeyAndVisible];
            [alertWindow.rootViewController presentViewController:alertController animated:YES completion:nil];
            
            if ([CompareString isEqualToString:@"Y"]) {
                UserIdString=[[json valueForKey:@"UserId"]objectAtIndex:0];
                PassArray=[[NSMutableArray alloc]initWithObjects:@"Weekly Entry",@"My Entry",@"Submit for PM Approval",@"Pending PM Approval",@"Assign Consultant to Project", nil];
                PassImgArray=[[NSMutableArray alloc]initWithObjects:@"Weekly.png",@"myentry.png",@"submit.png",@"pennding.png",@"assign.png", nil];
                //PassArray=[[NSMutableArray alloc]initWithObjects:@"Weekly Entry",@"My Entry",@"Submit for PM Approval", nil];
                
                MenuVC = (MenuViewController*)  self.window.rootViewController;
                MenuVC.MenuTableItemArray=PassArray;
                MenuVC.MenuTableImgArray=PassImgArray;
            }
            else{
                UserIdString=[[json valueForKey:@"UserId"]objectAtIndex:0];
                
                MenuVC = (MenuViewController*)  self.window.rootViewController;
                
                PassArray=[[NSMutableArray alloc]initWithObjects:@"Weekly Entry",@"My Entry",@"Submit for PM Approval", nil];
                PassImgArray=[[NSMutableArray alloc]initWithObjects:@"Weekly.png",@"myentry.png",@"submit.png", nil];
                MenuVC.MenuTableItemArray=PassArray;
                MenuVC.MenuTableImgArray=PassImgArray;
            }
            
        }
        else
        {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Login" message:@"Login Failed" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            UIWindow *alertWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
            alertWindow.rootViewController = [[UIViewController alloc] init];
            alertWindow.windowLevel = UIWindowLevelAlert + 1;
            [alertWindow makeKeyAndVisible];
            [alertWindow.rootViewController presentViewController:alertController animated:YES completion:nil];
            
            
        }
        
        UINavigationController *navigation = [[UINavigationController alloc]initWithRootViewController:MenuVC];
        self.window.rootViewController = navigation;

        
        

    }
    else
    {
        NSLog(@"Device is not connected to the Internet");
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Warning" message:@"No InternetConnection" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        UIWindow *alertWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        alertWindow.rootViewController = [[UIViewController alloc] init];
        alertWindow.windowLevel = UIWindowLevelAlert + 1;
        [alertWindow makeKeyAndVisible];
        [alertWindow.rootViewController presentViewController:alertController animated:YES completion:nil];

    }
    /*
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MGet_ValidateUser"]];
    
    
    //create the Method "GET" or "POST"
    [request setHTTPMethod:@"POST"];
    
    //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
    NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput={'sIMEINo' :'002ebf12-a125-5ddf-a739-67c3c5d20188'}"];
    
    
    
    //Check The Value what we passed
    NSLog(@"the data Details is =%@", userUpdate);
    
    //Convert the String to Data
    NSData *data1 = [userUpdate dataUsingEncoding:NSUTF8StringEncoding];
    
    //Apply the data to the body
    [request setHTTPBody:data1];
   // [request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
    
    //Create the response and Error
    NSError *err;
    NSURLResponse *response;
    
    NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
    
    NSString *resSrt = [[NSString alloc]initWithData:responseData encoding:NSASCIIStringEncoding];
    NSLog(@"got response==%@", resSrt);
    if(resSrt)
    {
        NSLog(@"got response");
    }
    else
    {
        NSLog(@"faield to connect");
    }

    NSError *e = nil;
    NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&e];
    NSLog(@"%@", json);
   // BOOL mine=[json objectAtIndex:]
    NSString *CompareString=[[json valueForKey:@"IsPM"]objectAtIndex:0];
    NSString *LoginStatus=[[json valueForKey:@"Status"]objectAtIndex:0];
    DbName=[[json valueForKey:@"DBName"]objectAtIndex:0];
    UserName=[[json valueForKey:@"UserName"]objectAtIndex:0];
    NSLog(@"%@",CompareString);
    //UIView *LoginSucessView=[[UIView alloc]initWithFrame:CGRectMake(0,0,, <#CGFloat height#>)
    if ([LoginStatus isEqualToString:@"Login Successful"]) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Login" message:@"Login Sucessed" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        UIWindow *alertWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        alertWindow.rootViewController = [[UIViewController alloc] init];
        alertWindow.windowLevel = UIWindowLevelAlert + 1;
        [alertWindow makeKeyAndVisible];
        [alertWindow.rootViewController presentViewController:alertController animated:YES completion:nil];
        
        if ([CompareString isEqualToString:@"Y"]) {
            UserIdString=[[json valueForKey:@"UserId"]objectAtIndex:0];
        PassArray=[[NSMutableArray alloc]initWithObjects:@"Weekly Entry",@"My Entry",@"Submit for PM Approval",@"Pending PM Approval",@"Assign Consultant to Project", nil];
            //PassArray=[[NSMutableArray alloc]initWithObjects:@"Weekly Entry",@"My Entry",@"Submit for PM Approval", nil];
            
         MenuVC = (MenuViewController*)  self.window.rootViewController;
            MenuVC.MenuTableItemArray=PassArray;
        }
        else{
            UserIdString=[[json valueForKey:@"UserId"]objectAtIndex:0];

          MenuVC = (MenuViewController*)  self.window.rootViewController;
            
            PassArray=[[NSMutableArray alloc]initWithObjects:@"Weekly Entry",@"My Entry",@"Submit for PM Approval", nil];
            MenuVC.MenuTableItemArray=PassArray;
        }
        
    }
    else
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Login" message:@"Login Failed" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        UIWindow *alertWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        alertWindow.rootViewController = [[UIViewController alloc] init];
        alertWindow.windowLevel = UIWindowLevelAlert + 1;
        [alertWindow makeKeyAndVisible];
        [alertWindow.rootViewController presentViewController:alertController animated:YES completion:nil];
    

    }
    
    UINavigationController *navigation = [[UINavigationController alloc]initWithRootViewController:MenuVC];
    self.window.rootViewController = navigation;
     */
        return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
