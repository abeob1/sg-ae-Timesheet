//
//  MenuTableViewCell.h
//  Timesheet
//
//  Created by electra on 1/10/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *MenuTableImgOutlet;
@property (strong, nonatomic) IBOutlet UILabel *MenuLabelOutlet;


@end
