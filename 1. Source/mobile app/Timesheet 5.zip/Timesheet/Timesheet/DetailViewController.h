//
//  DetailViewController.h
//  Timesheet
//
//  Created by electra on 1/18/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ItemTableViewCell.h"

@interface DetailViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UIDatePicker * datePicker;
}
@property (strong, nonatomic) IBOutlet UIButton *AddButtonOutlet;

@property (strong, nonatomic) IBOutlet UITextField *DateTxtOutlet;

- (IBAction)AddButtonTapped:(id)sender;
- (IBAction)FilterButtonTapped:(id)sender;
- (IBAction)BackButtonTapped:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *TableViewOutlet;


@end
