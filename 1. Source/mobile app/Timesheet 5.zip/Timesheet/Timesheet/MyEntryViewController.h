//
//  MyEntryViewController.h
//  Timesheet
//
//  Created by electra on 1/11/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddViewController.h"
#import "MyEntryTableViewCell.h"
#import "AppDelegate.h"

@interface MyEntryViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>
{
    UIDatePicker *datePicker;
    UITableView *dropDownTableView,*dropDownTableView1;
    NSMutableArray *typeArray,*ProjectCode,*ProjectName,*PrCode,*PrName,*PrDate,*ProJecDate,*Hour,*GrandTotal;
    
    NSString *Status,*PrcString,*UserString,*GrantTotalString;
   IBOutlet UILabel *NoDataFoundLabelOutlet;
    UITableView *MyEntryDisplayTableView;

}

@property (strong, nonatomic) IBOutlet UITextField *FromDateTxt;

@property (strong, nonatomic) IBOutlet UITextField *ToDateTxt;
@property(strong,nonatomic)AddViewController *HeaderView;
@property (strong, nonatomic) IBOutlet UIButton *FilterButtonOutlet;
@property (strong, nonatomic) IBOutlet UITableView *TableviewOutlet;
@property (strong, nonatomic) IBOutlet UITextField *DropdownTxtOutlet;
@property (strong, nonatomic) IBOutlet UITextField *Dropdown1TxtOutlet;

- (IBAction)FilterButtonTapped:(id)sender;

- (IBAction)BackButtonTapped:(id)sender;
- (IBAction)LogoutButtonTapped:(id)sender;

@end
