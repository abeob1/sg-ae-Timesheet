//
//  WeeklyViewController.m
//  Timesheet
//
//  Created by electra on 1/10/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import "WeeklyViewController.h"

@interface WeeklyViewController ()

@end

@implementation WeeklyViewController
{
    UIAlertView * LogoutAlert;
    UIButton * btnDone;
    NSMutableArray *DsArray;
    UIToolbar *toolBar;
    UIActivityIndicatorView *activity;
    UILabel*NodataLbelOutlet;
    NSString *SelectDate;
    float a,b,c,d,e,f,g,z;
    int row1;
}
@synthesize FromTextOutlet,AddButtonOutlet,FromDateTxtOutlet,SaveEntryButtonOutlet,SaveString,dbName,TableViewOutlet,ClearButton;

- (void)viewDidLoad {
    [super viewDidLoad];

    //av.tag  = 1;
    [self.view addSubview:activity];
    FromTextOutlet.layer.borderWidth=1.2;
    [[FromTextOutlet layer]setBorderColor:[UIColor whiteColor].CGColor];
    AddButtonOutlet.layer.cornerRadius=3;
    DatatNotFoundLabel.text=@"No Data";
    //date picker creating
   datePicker = [[UIDatePicker alloc]init];
    datePicker.datePickerMode = UIDatePickerModeDate;
    [FromDateTxtOutlet setInputView:datePicker];
    toolBar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,35)];
    [toolBar setTintColor:[UIColor grayColor]];
    UIBarButtonItem *doneBtn = [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(ShowSelectedDate)];
    UIBarButtonItem *space = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [toolBar setItems:[NSArray arrayWithObjects:space,doneBtn, nil]];
    
    [FromDateTxtOutlet setInputAccessoryView:toolBar];

    DsArray=[[NSMutableArray alloc]init];
    //[DsArray addObject:@"0"];
    NSLog(@"%@",DsArray);
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    SaveString = appDelegate.UserIdString;
    dbName=appDelegate.DbName;
    UserName=appDelegate.UserName;
    TableViewOutlet.separatorStyle = UITableViewCellSeparatorStyleNone;
    NodataLbelOutlet=[[UILabel alloc]init];
    [NodataLbelOutlet setCenter:CGPointMake(self.view.frame.size.width / 2, self.view.frame.size.height / 2)];
    NodataLbelOutlet.text=@"No Data Found";
    NodataLbelOutlet.textColor=[UIColor whiteColor];
    [TableViewOutlet addSubview:NodataLbelOutlet];
    ProjectName=[[NSMutableArray alloc]init];

    PsTo=[[NSMutableArray alloc]init];

    [PsTo addObject:@"1"];
    [ClearButton addTarget:self
               action:@selector(aMethod:)
     forControlEvents:UIControlEventTouchUpInside];
   
    //ProjectCode1=[[NSMutableArray alloc]init];
    // Do any additional setup after loading the view.
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
-(void)ShowSelectedDate
{
   // return startOfTheWeek;
    
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"YYYY-MM-dd"];
   // if ([FromTextOutlet isFirstResponder])
    
        SelectDate=[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]];
    FromDateTxtOutlet.text=SelectDate;

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"EEEE"];
    NSLog(@"The day of the week: %@", [dateFormatter stringFromDate:datePicker.date]);
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    [gregorian setFirstWeekday:2];
  // NSDateComponents *comps = [gregorian components:NSCalendarUnitWeekday fromDate:datePicker.date];
    NSUInteger adjustedWeekdayOrdinal = [gregorian ordinalityOfUnit:NSWeekdayCalendarUnit inUnit:NSWeekCalendarUnit forDate:datePicker.date];
    NSLog(@"Adjusted weekday ordinal: %d", adjustedWeekdayOrdinal);
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
    NSDateComponents *components=[[NSDateComponents alloc] init];
    if (adjustedWeekdayOrdinal==1) {
        components.day=0;
        NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
        ;
        NSLog(@"%@",targetDate);
        stringDateOutlet = [formatter stringFromDate:targetDate];
    }
    else if (adjustedWeekdayOrdinal==2)
    {
        
        components.day=-1;
        NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
        ;
        NSLog(@"%@",targetDate);
        stringDateOutlet = [formatter stringFromDate:targetDate];
        NSLog(@"%@",stringDateOutlet);
        //FromDateTxtOutlet.text=stringDateOutlet;
       
    }
    else if (adjustedWeekdayOrdinal==3)
    {
        components.day=-2;
        NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
        ;
        NSLog(@"%@",targetDate);
        stringDateOutlet = [formatter stringFromDate:targetDate];
        NSLog(@"%@",stringDateOutlet);
       // FromDateTxtOutlet.text=stringDateOutlet;


 
    }
    else if (adjustedWeekdayOrdinal==4)
    {
        components.day=-3;
        NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
        ;
        NSLog(@"%@",targetDate);
        stringDateOutlet = [formatter stringFromDate:targetDate];
        NSLog(@"%@",stringDateOutlet);
       // FromDateTxtOutlet.text=stringDateOutlet;
    }
    else if (adjustedWeekdayOrdinal==5)
    {
        components.day=-4;
        NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
        ;
        NSLog(@"%@",targetDate);
        stringDateOutlet = [formatter stringFromDate:targetDate];
        NSLog(@"%@",stringDateOutlet);
       // FromDateTxtOutlet.text=stringDateOutlet;


    }
    else if (adjustedWeekdayOrdinal==6)
    {
        components.day=-5;
        NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
        ;
        NSLog(@"%@",targetDate);
        stringDateOutlet = [formatter stringFromDate:targetDate];
        NSLog(@"%@",stringDateOutlet);
       // FromDateTxtOutlet.text=stringDateOutlet;


    }
    else if (adjustedWeekdayOrdinal==7)
    {
        components.day=-6;
        NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
        ;
        NSLog(@"%@",targetDate);
        stringDateOutlet = [formatter stringFromDate:targetDate];
        NSLog(@"%@",stringDateOutlet);
       // FromDateTxtOutlet.text=stringDateOutlet;


 
    }
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd"];
    NSDate *date3 = [dateFormat dateFromString:stringDateOutlet];
    components.day=+6;
    NSDate *targetDate =[calendar dateByAddingComponents:components toDate:date3 options: 0]
    ;
    NSLog(@"%@",targetDate);
    ToStringDate = [formatter stringFromDate:targetDate];
    NSLog(@"%@",ToStringDate);
    
    [datePicker removeFromSuperview];
    [toolBar removeFromSuperview];

    //int weekday = [adjusted weekday];
    
   // NSLog(@"The week day number: %d", weekday);
    
   /*
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"EEEE"];
    NSLog(@"The day of the week: %@", [dateFormatter stringFromDate:[NSDate date]]);
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *comps = [gregorian components:NSCalendarUnitWeekday fromDate:[NSDate date]];
    int weekday = [comps weekday];
    NSLog(@"The week day number: %d", weekday);

}
-(void)viewDidAppear:(BOOL)animated{
    
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
}

- (IBAction)LogoutButtonTapped:(id)sender {
    LogoutAlert = [[UIAlertView alloc]
                   initWithTitle:@"Confirmation"
                   message:@"Are you sure you want to Logout "
                   delegate:self
                   cancelButtonTitle:@"No"
                   otherButtonTitles:@"yes",nil];
    [LogoutAlert show];
    LogoutAlert.delegate=self;
    // [self.navigationController popToRootViewControllerAnimated:YES];
}

- (IBAction)BackButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if(buttonIndex == 0)//OK button pressed
    {
        NSLog(@"0");
    }
    else if(buttonIndex == 1)//Annul button pressed.
    {
        [self.navigationController popToRootViewControllerAnimated:YES];
         }
}

- (IBAction)AddButtonTapped:(id)sender {
    
    if ([FromDateTxtOutlet.text isEqualToString:@""]) {
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Warning"
                                     message:@"Please select date"
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* yesButton = [UIAlertAction
                                    actionWithTitle:@"ok"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        
                                        
                                        
                                        
                                        //Handle your yes please button action here
                                    }];
        
        
        [alert addAction:yesButton];
        
        [self presentViewController:alert animated:YES completion:nil];

    }
    else
    {

    NSURL *url = [NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MGet_ProjectList"];

    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    NSString *SaveString = appDelegate.UserIdString;
    
    NSDictionary *o1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:dbName, @"sDBName",SaveString, @"sUserId",nil];
    //FilterInputArray=[NSMutableArray arrayWithObject:o1];
    //create the Method "GET" or "POST"
    NSError *error;
    [request setHTTPMethod:@"POST"];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:o1 options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *jsonString1=[NSString stringWithFormat:@"sJsonInput=%@",jsonString];
    
    //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
    // NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput={'sDBName' : 'ABEO_INTL'}"];
   
    
    
    //Check The Value what we passed
    // NSLog(@"the data Details is =%@", userUpdate);
    
    //Convert the String to Data
    NSData *data1 = [jsonString1 dataUsingEncoding:NSUTF8StringEncoding];
    [request setHTTPBody:data1];
    // [request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
    NSError *err;
    NSURLResponse *response;
    
    NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
    
    NSString *resSrt = [[NSString alloc]initWithData:responseData encoding:NSASCIIStringEncoding];
    NSLog(@"got response==%@", resSrt);
    NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&err];
    NSLog(@"%@", json);
    ProjectCode=[json valueForKey:@"PrjCode"];
    ProjectName=[json valueForKey:@"PrjName"];

    
    //[request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
    //NSLog(@"%@",InputArray);
    
    //Apply the data to the body
    //[request setHTTPBody:data1];
    /*
    NSURLSessionDataTask *task =
    [[NSURLSession sharedSession] dataTaskWithRequest:request
                                    completionHandler:^(NSData *data,
                                                        NSURLResponse *response,
                                                        NSError *error) {
                                        
                                        NSString *resSrt = [[NSString alloc]initWithData:data encoding:NSASCIIStringEncoding];
                                        NSLog(@"got response==%@", resSrt);
                                        
                                        
                                        NSError *e = nil;
                                        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&e];
                                        NSLog(@"%@", json);
                                        
                                        // Code to run when the response completes...
                                    }];
    [task resume];
     */

    SearchView=[[UIView alloc]initWithFrame:CGRectMake(30,AddButtonOutlet.frame.origin.y+33,self.view.frame.size.width/1.2,self.view.frame.size.width+90)];
    [self.view addSubview:SearchView];
    SearchView.layer.borderWidth=1;
   // SearchView.backgroundColor=[UIColor redColor];
    UISearchBar * searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0,self.view.frame.size.width/1.2,30)];
    [SearchView addSubview:searchBar];
    //searchBar.layer.cornerRadius=5;
    SearchtableView = [[UITableView alloc] initWithFrame:CGRectMake(0,30,self.view.frame.size.width/1.2,self.view.frame.size.width+60)];
   // SearchtableView.layer.cornerRadius=5;
    SearchtableView.delegate =self;
    SearchtableView.dataSource =self;
    SearchtableView.tag=2;
    // must set delegate & dataSource, otherwise the the table will be empty and not responsive
    
    //tableView.backgroundColor = [UIColor cyanColor];
    [SearchView addSubview:SearchtableView];
    /*
    AddView = [self.storyboard instantiateViewControllerWithIdentifier:@"AddViewController"];
    AddView.view.frame=CGRectMake(20,60,280,440);
    AddView.view.layer.cornerRadius=5;
    [self.view addSubview:AddView.view];
     
*/
    }

}

- (IBAction)FilterButtonTapped:(id)sender {
    
    if ([FromDateTxtOutlet.text isEqualToString:@""]) {
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Warning"
                                     message:@"Please select date"
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* yesButton = [UIAlertAction
                                    actionWithTitle:@"ok"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        
                                        
                                        
                                        
                                        //Handle your yes please button action here
                                    }];
        
        
        [alert addAction:yesButton];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }
    else
    {

    [activity startAnimating];

    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MGet_FilterWeeklyEntry"]];
    
    NSDictionary *o1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:stringDateOutlet, @"sIN_BeginDate",UserName, @"sIN_UserCode",nil];
    FilterInputArray=[NSMutableArray arrayWithObject:o1];
    //create the Method "GET" or "POST"
    NSError *error;
    [request setHTTPMethod:@"POST"];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:FilterInputArray options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
   NSString *jsonString1=[NSString stringWithFormat:@"sJsonInput=%@",jsonString];
    //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
    // NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput={'sDBName' : 'ABEO_INTL'}"];
    
    
    
    //Check The Value what we passed
    // NSLog(@"the data Details is =%@", userUpdate);
    
    //Convert the String to Data
    NSData *data1 = [jsonString1 dataUsingEncoding:NSUTF8StringEncoding];
    //[request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
    //NSLog(@"%@",InputArray);
    
    //Apply the data to the body
   [request setHTTPBody:data1];
    NSURLSessionDataTask *task =
    [[NSURLSession sharedSession] dataTaskWithRequest:request
                                    completionHandler:^(NSData *data,
                                                        NSURLResponse *response,
                                                        NSError *error) {
                                        
                                        NSString *resSrt = [[NSString alloc]initWithData:data encoding:NSASCIIStringEncoding];
                                        NSLog(@"got response==%@", resSrt);
                                        
                                        
                                        NSError *e = nil;
                                        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&e];
                                        NSLog(@"%@", json);
                                        if ([json count] == 0)
                                        {
                                            dispatch_async(dispatch_get_main_queue(), ^{

                                            
                                            UIAlertController * alert1 = [UIAlertController
                                                                         alertControllerWithTitle:@"Warning"
                                                                         message:@"No Data Found"
                                                                         preferredStyle:UIAlertControllerStyleAlert];
                                            
                                            UIAlertAction* yesButton = [UIAlertAction
                                                                        actionWithTitle:@"Ok"
                                                                        style:UIAlertActionStyleDefault
                                                                        handler:^(UIAlertAction * action) {
                                                                            [datePicker removeFromSuperview];
                                                                            [toolBar removeFromSuperview];

                                                                            //Handle your yes please button action here
                                                                        }];
                                            
                                            [alert1 addAction:yesButton];
                                            
                                            [self presentViewController:alert1 animated:YES completion:nil];
                                            });
                                        }
                                        
                                        else
                                        {
                                            dispatch_async(dispatch_get_main_queue(), ^{

                                            NSLog(@"1");
                                            ProjectCode1=[json valueForKey:@"PrjCode"];
                                                 ProjectName1=[[NSMutableArray alloc]init];
                                            ProjectName1=[json valueForKey:@"PrjName"];
                                            StatusString=[[json valueForKey:@"Status"]objectAtIndex:0];
                                                StatusArray=[json valueForKey:@"Status"];
                                                IDsArray=[json valueForKey:@"IDS"];
                                                TaskArray=[json valueForKey:@"Task"];
                                            Mon=[json valueForKey:@"Mon"];
                                            Tue=[json valueForKey:@"Tue"];
                                            Wed=[json valueForKey:@"Wed"];
                                            Thu=[json valueForKey:@"Thu"];
                                            Fri=[json valueForKey:@"Fri"];
                                            Sat=[json valueForKey:@"Sat"];
                                            Sun=[json valueForKey:@"Sun"];
                                            TotalArray=[json valueForKey:@"Total"];
                                            NSLog(@"%@",StatusString);
                                            TableViewOutlet.dataSource=self;
                                            TableViewOutlet.delegate=self;
                                            [TableViewOutlet reloadData];
                                                
                                            });
                                        }

                                        [activity stopAnimating];
                                        // Code to run when the response completes...
                                    }];
    
    [task resume];

}
}

-(void) dueDateChanged:(UIDatePicker *)sender {
    NSDateFormatter* dateFormatter =[[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle:NSDateFormatterLongStyle];
    [dateFormatter setTimeStyle:NSDateFormatterNoStyle];
    
    //self.myLabel.text = [dateFormatter stringFromDate:[dueDatePickerView date]];
    NSLog(@"Picked the date %@", [dateFormatter stringFromDate:[sender date]]);
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView==SearchtableView) {
        return [ProjectName count];
    }
    else
    {
        return [ProjectCode1 count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (tableView==SearchtableView) {
        static NSString *simpleTableIdentifier = @"SearchTableViewCell";
        
        SearchTableViewCell*cell = (SearchTableViewCell *)[SearchtableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SearchTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            SearchtableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
            cell.ProjectNameOutlet.text=[ProjectName objectAtIndex:indexPath.row];
            cell.ProjectCodeOutlet.text=[ProjectCode objectAtIndex:indexPath.row];
            
        }
        return cell;
    }
    else{
        static NSString *simpleTableIdentifier = @"ItemTableViewCell";
        
        ItemTableViewCell*cell1 = (ItemTableViewCell *)[TableViewOutlet dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell1 == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ItemTableViewCell" owner:self options:nil];
            cell1 = [nib objectAtIndex:0];
            //SearchtableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
            int i;
            cell1.SegmentControll.tag = indexPath.row;

            NSNumber *number=[NSNumber numberWithInt:i];
            cell1.layer.cornerRadius=5;
            cell1.layer.borderWidth=1;
            [cell1.SegmentControll addTarget:self action:@selector(SegmentChangeViewValueChanged:) forControlEvents:UIControlEventValueChanged];
            [cell1 setSelectionStyle:UITableViewCellSelectionStyleNone];

            cell1.ProjectNameOutlet.text=[ProjectName1 objectAtIndex:indexPath.row];
            cell1.ProjectCodeOutlet.text=[ProjectCode1 objectAtIndex:indexPath.row];
            cell1.TotalOutLet.text=[TotalArray objectAtIndex:indexPath.row];
            cell1.FromDateOutlet.text=stringDateOutlet;
            cell1.TodateOutlet.text=ToStringDate;
            cell1.TaskOutlet.text=[TaskArray objectAtIndex:indexPath.row];
            cell1.MonOutlet.text=[Mon objectAtIndex:indexPath.row];
            cell1.TueOutlet.text=[Tue objectAtIndex:indexPath.row];
            cell1.WedOutlet.text=[Wed objectAtIndex:indexPath.row];
            cell1.ThuOutlet.text=[Thu objectAtIndex:indexPath.row];
            cell1.FriOutlet.text=[Fri objectAtIndex:indexPath.row];
            cell1.SatOutlet.text=[Sat objectAtIndex:indexPath.row];
            cell1.SunOutlet.text=[Sun objectAtIndex:indexPath.row];
            cell1.MonOutlet.delegate=self;
            cell1.TueOutlet.delegate=self;
            cell1.WedOutlet.delegate=self;
            cell1.ThuOutlet.delegate=self;
            cell1.FriOutlet.delegate=self;
            cell1.SatOutlet.delegate=self;
            cell1.SunOutlet.delegate=self;
            cell1.StatusInputLabel.text=@"Entry";
            //if ([StatusString isEqualToString:@"1"]) {
            if ([StatusArray containsObject:@"1"]) {

                cell1.SegmentControll.hidden=YES;
                cell1.StatusInputLabel.text=@"Status:";
                cell1.StatusOutputLabel.text=@"Pending for Approval";
                cell1.MonOutlet.userInteractionEnabled=NO;
                cell1.TueOutlet.userInteractionEnabled=NO;
                cell1.WedOutlet.userInteractionEnabled=NO;
                cell1.ThuOutlet.userInteractionEnabled=NO;
                cell1.FriOutlet.userInteractionEnabled=NO;
                cell1.SatOutlet.userInteractionEnabled=NO;
                cell1.SunOutlet.userInteractionEnabled=NO;



            }
           // else if ([StatusString isEqualToString:@"2"])
                else if ([StatusArray containsObject:@"2"])

            {
                cell1.SegmentControll.hidden=YES;
                cell1.StatusInputLabel.text=@"Status:";
                cell1.StatusOutputLabel.text=@"Approved";
                cell1.MonOutlet.userInteractionEnabled=NO;
                cell1.TueOutlet.userInteractionEnabled=NO;
                cell1.WedOutlet.userInteractionEnabled=NO;
                cell1.ThuOutlet.userInteractionEnabled=NO;
                cell1.FriOutlet.userInteractionEnabled=NO;
                cell1.SatOutlet.userInteractionEnabled=NO;
                cell1.SunOutlet.userInteractionEnabled=NO;



            }
            //else if ([StatusString isEqualToString:@"0"])
            else if ([StatusArray containsObject:@"0"])

            {
                cell1.SegmentControll.hidden=NO;
                cell1.StatusInputLabel.text=@"Entry";
                cell1.StatusOutputLabel.text=@"";
                [cell1.SegmentControll setTitle:@"Edit" forSegmentAtIndex:1];
                [cell1.SegmentControll setTitle:@"Delete" forSegmentAtIndex:0];
                cell1.MonOutlet.userInteractionEnabled=NO;
                cell1.TueOutlet.userInteractionEnabled=NO;
                cell1.WedOutlet.userInteractionEnabled=NO;
                cell1.ThuOutlet.userInteractionEnabled=NO;
                cell1.FriOutlet.userInteractionEnabled=NO;
                cell1.SatOutlet.userInteractionEnabled=NO;
                cell1.SunOutlet.userInteractionEnabled=NO;


            }
            SegmentTitleone = [cell1.SegmentControll titleForSegmentAtIndex:0];
            SegmentTitle2 = [cell1.SegmentControll titleForSegmentAtIndex:1];


        }
        return cell1;
    }

        
    }
    /*
    else
    {
        if (tableView==TableviewOutlet) {
            static NSString *simpleTableIdentifier = @"SearchTableViewCell";
            
            SearchTableViewCell*cell1 = (SearchTableViewCell *)[TableviewOutlet dequeueReusableCellWithIdentifier:simpleTableIdentifier];
            if (cell1 == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SearchTableViewCell" owner:self options:nil];
                cell1 = [nib objectAtIndex:0];
                cell1.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                TableviewOutlet.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
                
            }
            return cell1;

            }
    }
    return 0;
}
*/

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
   
    if (tableView==SearchtableView) {
        return 73;
    }
    else{
        return 218;

    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    if (tableView==SearchtableView) {
        int a=indexPath.row;
       // NSIndexPath *indexPath = [NSIndexPath indexPathForRow:a inSection:0];  //you should set your indexes of row and section instead of zeros
       SearchTableViewCell *cell = [SearchtableView cellForRowAtIndexPath:indexPath];
        NSLog(@"%@",ProjectName1);
        NSMutableArray *innerArray = [[NSMutableArray alloc]init];
        NSMutableArray *innerArray1=[[NSMutableArray alloc]init];
        NSMutableArray *innerArray2=[[NSMutableArray alloc]init];
        NSMutableArray *innerArray3=[[NSMutableArray alloc]init];
        NSMutableArray *innerArray4=[[NSMutableArray alloc]init];
        NSMutableArray *innerArray5=[[NSMutableArray alloc]init];

        NSMutableArray *innerArray6=[[NSMutableArray alloc]init];
        NSMutableArray *innerArray7=[[NSMutableArray alloc]init];
        NSMutableArray *innerArray8=[[NSMutableArray alloc]init];
        NSMutableArray *innerArray9=[[NSMutableArray alloc]init];
        NSMutableArray *innerArray10=[[NSMutableArray alloc]init];
        NSMutableArray *innerArray11=[[NSMutableArray alloc]init];

        NSLog(@"%@",cell.ProjectNameOutlet.text);
       // [ProjectName1 addObject:@"test"];
        
        for (int i=0; i<ProjectName1.count; i++)
        {
            [innerArray addObject:[ProjectName1 objectAtIndex:i]];
        }
        
        [innerArray addObject:cell.ProjectNameOutlet.text];
        
        
        ProjectName1=[[NSMutableArray alloc]init];
        for (int i=0; i<innerArray.count; i++)
        {
            [ProjectName1 addObject:[innerArray objectAtIndex:i]];
        }
        
        for (int i=0; i<[ProjectCode1 count];i++) {
            [innerArray1 addObject:[ProjectCode1 objectAtIndex:i]];

        }
        [innerArray1 addObject:cell.ProjectCodeOutlet.text];

        ProjectCode1=[[NSMutableArray alloc]init];
        for (int i=0; i<[innerArray1 count];i++) {
            [ProjectCode1 addObject:[innerArray1 objectAtIndex:i]];

        }
        NSLog(@"%@",TotalArray);
        
        for (int i=0; i<[TotalArray count];i++) {
            [innerArray2 addObject:[TotalArray objectAtIndex:i]];
            
        }
        [innerArray2 addObject:@"0.00"];
        
        TotalArray=[[NSMutableArray alloc]init];
        for (int i=0; i<[innerArray2 count];i++) {
            [TotalArray addObject:[innerArray2 objectAtIndex:i]];
            
        }
        /////////////////////////////////////////////

        
        for (int i=0; i<[Mon count];i++) {
            [innerArray3 addObject:[Mon objectAtIndex:i]];
            
        }
        [innerArray3 addObject:@"0.00"];
        
        Mon=[[NSMutableArray alloc]init];
        for (int i=0; i<[innerArray3 count];i++) {
            [Mon addObject:[innerArray3 objectAtIndex:i]];
            
        }
        for (int i=0; i<[Tue count];i++) {
            [innerArray4 addObject:[Tue objectAtIndex:i]];
            
        }
        [innerArray4 addObject:@"0.00"];
        
        Tue=[[NSMutableArray alloc]init];
        for (int i=0; i<[innerArray3 count];i++) {
            [Tue addObject:[innerArray4 objectAtIndex:i]];
            
        }

        ///////////////////////////////////
        for (int i=0; i<[Wed count];i++) {
            [innerArray5 addObject:[Wed objectAtIndex:i]];
            
        }
        [innerArray5 addObject:@"0.00"];
        
        Wed=[[NSMutableArray alloc]init];
        for (int i=0; i<[innerArray5 count];i++) {
            [Wed addObject:[innerArray5 objectAtIndex:i]];
            
        }
////////////////////////////////////////////
        for (int i=0; i<[Thu count];i++) {
            [innerArray6 addObject:[Thu objectAtIndex:i]];
            
        }
        [innerArray6 addObject:@"0.00"];
        
        Thu=[[NSMutableArray alloc]init];
        for (int i=0; i<[innerArray6 count];i++) {
            [Thu addObject:[innerArray6 objectAtIndex:i]];
            
        }
//////////////////////////////////
        
        for (int i=0; i<[Fri count];i++) {
            [innerArray7 addObject:[Fri objectAtIndex:i]];
            
        }
        [innerArray7 addObject:@"0.00"];
        
        Fri=[[NSMutableArray alloc]init];
        for (int i=0; i<[innerArray7 count];i++) {
            [Fri addObject:[innerArray7 objectAtIndex:i]];
            
        }

        /////////////////////////
        
        for (int i=0; i<[Sat count];i++) {
            [innerArray8 addObject:[Sat objectAtIndex:i]];
            
        }
        [innerArray8 addObject:@"0.00"];
        
        Sat=[[NSMutableArray alloc]init];
        for (int i=0; i<[innerArray8 count];i++) {
            [Sat addObject:[innerArray8 objectAtIndex:i]];
            
        }
        ///////////////////////////
        for (int i=0; i<[Sun count];i++) {
            [innerArray9 addObject:[Sun objectAtIndex:i]];
            
        }
        [innerArray9 addObject:@"0.00"];
        
        Sun=[[NSMutableArray alloc]init];
        for (int i=0; i<[innerArray9 count];i++) {
            [Sun addObject:[innerArray9 objectAtIndex:i]];
            
        }
////////////////////////////
        for (int i=0; i<[TaskArray count];i++) {
            [innerArray10 addObject:[TaskArray objectAtIndex:i]];
            
        }
        [innerArray10 addObject:@"task"];
        
        TaskArray=[[NSMutableArray alloc]init];
        for (int i=0; i<[innerArray10 count];i++) {
            [TaskArray addObject:[innerArray10 objectAtIndex:i]];
            
        }
/////////////////////////////////
        for (int i=0; i<[IDsArray count];i++) {
            [innerArray11 addObject:[TaskArray objectAtIndex:i]];
            
        }
        [innerArray11 addObject:@"0;0;0;0;0;0;0"];
        
        IDsArray=[[NSMutableArray alloc]init];
        for (int i=0; i<[innerArray11 count];i++) {
            [IDsArray addObject:[innerArray11 objectAtIndex:i]];
            
        }


         //[ProjectName1 addObject:cell.ProjectNameOutlet.text];
       // ProjectCode1=[[NSMutableArray alloc]init];
        //[ProjectCode1 addObject:cell.ProjectCodeOutlet.text];
        

       // innerArray=cell.ProjectCodeOutlet.text;
        

    [SearchView removeFromSuperview];
    /*
    TableViewOut = [[UITableView alloc] initWithFrame:CGRectMake(0,94,self.view.frame.size.width,self.view.frame.size.width+120)];
    [self.view addSubview:TableViewOut];
     */
    [DsArray addObject:@"1"];
    
    // must set delegate & dataSource, otherwise the the table will be empty and not responsive
    
   // TableViewOut.backgroundColor = [UIColor cyanColor];
    
    // add to canvas
    //[self.view addSubview:tableView];
    TableViewOutlet.delegate=self;
    TableViewOutlet.dataSource=self;
    [TableViewOutlet reloadData];
    [SearchView removeFromSuperview];

    }
    else
    {
        
    }
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{    NSLog(@"2");
       return YES;
}
-(void)SegmentChangeViewValueChanged:(id)sender
{
    NSLog(@"changed");
    UISegmentedControl *s = (UISegmentedControl *)sender;

    NSLog(@"current Row=%d",s.tag);

    row1=s.tag;
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:s.tag inSection:0];  //you should set your indexes of row and section instead of zeros
    ItemTableViewCell *cell1 = [TableViewOutlet cellForRowAtIndexPath:indexPath];
    
   // int row=indexPath.row;
    NSString *projname= cell1.ProjectNameOutlet.text;
    NSString *projCode=cell1.ProjectCodeOutlet.text;
    idssString=[IDsArray objectAtIndex:s.tag];

    
    
    if (s.selectedSegmentIndex==0) {
        
        if ([SegmentTitleone isEqualToString:@"Cancel"]) {
            NSLog(@"%@",ProjectCode);
            NSLog(@"%@",TotalArray);

if ([TotalArray count] == 0)
{
        [PsTo removeAllObjects];
    [TableViewOutlet reloadData];
    
}
  else
  {
    
    
    [TableViewOutlet reloadData];

  }

        }
        else
        {
            NSLog(@"delete");
            UIAlertController * alert = [UIAlertController
                                         alertControllerWithTitle:@"Confirmation"
                                         message:@"Are you sure you want to delete"
                                         preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* yesButton = [UIAlertAction
                                        actionWithTitle:@"Yes"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {
                                            NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/DeleteWeeklyEntry"]];
                                            
                                            
                                            //create the Method "GET" or "POST"
                                            NSError *error;
                                            [request setHTTPMethod:@"POST"];
                                            
                                            
                                            
                                            NSString *str1=[NSString stringWithFormat:@"Ids=%@",idssString];
                                            NSData *data1 = [str1 dataUsingEncoding:NSUTF8StringEncoding];
                                            [request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
                                            
                                            //Apply the data to the body
                                            [request setHTTPBody:data1];
                                            NSError *err;
                                            NSURLResponse *response;
                                            
                                            NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
                                            
                                            NSString *resSrt = [[NSString alloc]initWithData:responseData encoding:NSASCIIStringEncoding];
                                            NSLog(@"got response==%@", resSrt);
                                            if(resSrt)
                                            {
                                                NSLog(@"got response");
                                            }
                                            else
                                            {
                                                NSLog(@"faield to connect");
                                            }
                                            
                                            NSError *e = nil;
                                            NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&e];
                                            NSLog(@"%@", json);

                                            [TableViewOutlet reloadData];
                                            
                                            
                                            //Handle your yes please button action here
                                        }];
            
            UIAlertAction* noButton = [UIAlertAction
                                       actionWithTitle:@"Cancel"
                                       style:UIAlertActionStyleDefault
                                       handler:^(UIAlertAction * action) {
                                           //Handle no, thanks button
                                       }];
            
            [alert addAction:yesButton];
            [alert addAction:noButton];
            
            [self presentViewController:alert animated:YES completion:nil];
            /*
            NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/DeleteWeeklyEntry"]];
            
            
            //create the Method "GET" or "POST"
            NSError *error;
            [request setHTTPMethod:@"POST"];
            
           
            
           NSString *str1=[NSString stringWithFormat:@"Ids=%@",IDsString];
                       NSData *data1 = [str1 dataUsingEncoding:NSUTF8StringEncoding];
            [request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
            
            //Apply the data to the body
            [request setHTTPBody:data1];
            
            NSURLSessionDataTask *task =
            [[NSURLSession sharedSession] dataTaskWithRequest:request
                                            completionHandler:^(NSData *data,
                                                                NSURLResponse *response,
                                                                NSError *error) {
                                                
                                                
                                                NSString *resSrt = [[NSString alloc]initWithData:data encoding:NSASCIIStringEncoding];
                                                NSLog(@"got response==%@", resSrt);
                                                
                                                
                                                NSError *e = nil;
                                                NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&e];
                                                NSLog(@"%@", json);

                                                
                                            }];
            [task resume];                                }
                                                     
                                                // Code to run when the response completes...
             

        [TableViewOutlet reloadData];
        
            
            
            
           */
            
        }

        
    }
    else
    {
        if ([SegmentTitle2 isEqualToString:@"Update"]) {
            NSLog(@"update");
            //UIAlertController * alert = [UIAlertController
                                         //alertControllerWithTitle:@"Warning"
                                        // message:@"Please select the fields"
                                        // preferredStyle:UIAlertControllerStyleAlert];
            
           
            
            //[self presentViewController:alert animated:YES completion:nil];

            if ([mon integerValue]>8) {
               // alert.message=@"Tues day date choosed more than 8 hours";
            }
                        else if ([tue integerValue]>8)
            {
                //alert.message=@"Tues day date choosed more than 8 hours";
 
            }
            else if ([wed integerValue]>8)
            {
                //alert.message=@"Wednesday date choosed more than 8 hours";

            }
            else if ([thu integerValue]>8)
            {
               // alert.message=@"thurs day date choosed more than 8 hours";

            }
            else if ([fri integerValue]>8)
            {
               // alert.message=@"Tues day date choosed more than 8 hours";
                
            }

            else if ([sat integerValue]>8)
            {
               // alert.message=@"Sat day date exceed";
 
            }
            else if ([sun integerValue]>8)
            {
               // alert.message=@"Sunday date exceed";
 
            }
            else
            {
                NSIndexPath *indexPath = [NSIndexPath indexPathForRow:s.tag inSection:0];  //you should set your indexes of row and section instead of zeros
                ItemTableViewCell *cell1 = [TableViewOutlet cellForRowAtIndexPath:indexPath];
                NSLog(@"here");
                
                a=[mon floatValue];
                b=[tue floatValue];
                c=[wed floatValue];
                d=[thu floatValue];
                e=[fri floatValue];
                f=[sat floatValue];
                g=[sun floatValue];


                z = a+b+c+d+e+f+g;
                cell1.TotalOutLet.text = [NSString stringWithFormat:@"%.02f", z];
                
                NSURL *url = [NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/UpdateWeeklyEntry"];
                
                NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
                AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
                NSString *SaveString = appDelegate.UserName;
                NSString *dbString=appDelegate.DbName;
                NSString *DbString=appDelegate.DbName;
                stringDateOutlet=[stringDateOutlet stringByReplacingOccurrencesOfString:@"-" withString:@""];
                
                NSDictionary *o1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:SaveString,@"UserCode",stringDateOutlet, @"Monday",projCode,@"PrjCode",projname,@"PrjName",task,@"Task",dbString,@"DBName",idssString,@"IDs",mon,@"Mon",tue,@"Tue",wed,@"Wed",thu,@"Thu",fri,@"Fri",sat,@"Sat",sun,@"Sun",nil];
                //FilterInputArray=[NSMutableArray arrayWithObject:o1];
                //create the Method "GET" or "POST"
                NSError *error;
                [request setHTTPMethod:@"POST"];
                NSMutableArray *inputArray=[[NSMutableArray alloc]init];
                [inputArray addObject:o1];
                
                
                NSData *jsonData = [NSJSONSerialization dataWithJSONObject:inputArray options:NSJSONWritingPrettyPrinted error:&error];
                NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
                NSString *jsonString1=[NSString stringWithFormat:@"sJsonInput=%@",jsonString];
                
                NSData *data1 = [jsonString1 dataUsingEncoding:NSUTF8StringEncoding];
                [request setHTTPBody:data1];
                // [request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
                [request setValue:@"length" forHTTPHeaderField:@"Content-Length"];

                NSError *err;
                NSURLResponse *response;
                
                NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
                
                NSString *resSrt = [[NSString alloc]initWithData:responseData encoding:NSASCIIStringEncoding];
                NSLog(@"got response==%@", resSrt);
                NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&err];
                NSLog(@"%@", json);
                NSString *ResultString=[[json valueForKey:@"Result"]objectAtIndex:0];
                if ([ResultString isEqualToString:@"SUCCESS"]) {
                    
                    
                    [cell1.SegmentControll setTitle:@"Delete" forSegmentAtIndex:0];
                    [cell1.SegmentControll setTitle:@"Edit" forSegmentAtIndex:1];
                    SegmentTitleone = [cell1.SegmentControll titleForSegmentAtIndex:0];
                    SegmentTitle2 = [cell1.SegmentControll titleForSegmentAtIndex:1];
                    
                    [cell1.SegmentControll setSelectedSegmentIndex:UISegmentedControlNoSegment];
                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"SUCCESS" message:@"Entry Updated Successfully" preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                    [alertController addAction:ok];
                    
                    [self presentViewController:alertController animated:YES completion:nil];
                    
                }
                else
                {
                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Warning" message:@"Error in updating" preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                    [alertController addAction:ok];
                    
                    [self presentViewController:alertController animated:YES completion:nil];
                }

                               //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
                // NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput={'sDBName' : 'ABEO_INTL'}"];
                
                
                
                 }
                

                
                
                
                
            
           
}
        else
        {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:s.tag inSection:0];  //you should set your indexes of row and section instead of zeros
            ItemTableViewCell *cell1 = [TableViewOutlet cellForRowAtIndexPath:indexPath];
            cell1.MonOutlet.userInteractionEnabled=YES;
            cell1.TueOutlet.userInteractionEnabled=YES;
            cell1.WedOutlet.userInteractionEnabled=YES;
            cell1.ThuOutlet.userInteractionEnabled=YES;
            cell1.FriOutlet.userInteractionEnabled=YES;
            cell1.SatOutlet.userInteractionEnabled=YES;
            cell1.SunOutlet.userInteractionEnabled=YES;
            [cell1.SegmentControll setTitle:@"Cancel" forSegmentAtIndex:0];
            [cell1.SegmentControll setTitle:@"Update" forSegmentAtIndex:1];
            SegmentTitleone = [cell1.SegmentControll titleForSegmentAtIndex:0];
            SegmentTitle2 = [cell1.SegmentControll titleForSegmentAtIndex:1];

            [cell1.SegmentControll setSelectedSegmentIndex:UISegmentedControlNoSegment];
        }
        
        
    }
    
}
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField==FromDateTxtOutlet) {
        
        
        [FromDateTxtOutlet resignFirstResponder];
        [FromDateTxtOutlet setInputView:datePicker];
        

    }
    else{
        
    }
    return YES;
}
-(BOOL)textFieldShouldReturn:(UITextField*)textField;
{
   // static NSString *simpleTableIdentifier = @"ItemTableViewCell";

   // ItemTableViewCell*cell1 = (ItemTableViewCell *)[TableViewOutlet dequeueReusableCellWithIdentifier:simpleTableIdentifier];
   // [cell1.MonOutlet resignFirstResponder];
    /*
    NSInteger nextTag = textField.tag + 1;
    // Try to find next responder
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    if (nextResponder) {
        // Found next responder, so set it.
        [nextResponder becomeFirstResponder];
    } else {
        // Not found, so remove keyboard.
        [textField resignFirstResponder];
    }
    return NO;
    */
    [textField resignFirstResponder];
    return YES;
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField==FromDateTxtOutlet) {
        
        
    }
    else
    {
   // textField = (UITextField*)[self.view viewWithTag:0];
   // NSString* textString=[textField text];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row1 inSection:0];  //you should set your indexes of row and section instead of zeros
    ItemTableViewCell *cell1 = [TableViewOutlet cellForRowAtIndexPath:indexPath];
    mon=cell1.MonOutlet.text;
    tue=cell1.TueOutlet.text;
    wed=cell1.WedOutlet.text;

    thu=cell1.ThuOutlet.text;

    fri=cell1.FriOutlet.text;
    sat=cell1.SatOutlet.text;
    sun=cell1.SunOutlet.text;
        task=cell1.TaskOutlet.text;
    
    }

}
-(void)aMethod:(id)sender
{
    NSLog(@"%@",FromDateTxtOutlet.text);
    NSString *str=FromDateTxtOutlet.text;
    if ([str isEqualToString:@""]) {
        
        
        dispatch_async(dispatch_get_current_queue(), ^{
            [FromDateTxtOutlet becomeFirstResponder];
        });
        FromDateTxtOutlet.inputView=datePicker;
        }
    else
    {
        FromDateTxtOutlet.text=@"";
       // self.view
    }
    }
@end
