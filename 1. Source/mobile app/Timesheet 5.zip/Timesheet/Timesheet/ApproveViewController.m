//
//  ApproveViewController.m
//  Timesheet
//
//  Created by electra on 1/13/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import "ApproveViewController.h"

@interface ApproveViewController ()
{
    NSMutableDictionary *DICT;
   // NSMutableArray *mon1,*tue1,*wed1,*thu1,*fri1,*sat1,*sun1;
}

@end

@implementation ApproveViewController
@synthesize ViewMoreButtonOutlet,TableOutlet,DatePickerText;

- (void)viewDidLoad {
    [super viewDidLoad];
    ViewMoreButtonOutlet.layer.cornerRadius=5;

    DayArray=[[NSMutableArray alloc]initWithObjects:@"Monday",@"Tuesday",@"Wednesday",@"Thursday",@"Friday",@"Saturday",@"Sunday", nil];
    
    
    datePicker = [[UIDatePicker alloc]init];
    datePicker.datePickerMode = UIDatePickerModeDate;
    [DatePickerText setInputView:datePicker];
    UIToolbar *toolBar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,35)];
    [toolBar setTintColor:[UIColor grayColor]];
    UIBarButtonItem *doneBtn = [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(ShowSelectedDate)];
    UIBarButtonItem *space = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [toolBar setItems:[NSArray arrayWithObjects:space,doneBtn, nil]];
    
    [DatePickerText setInputAccessoryView:toolBar];
    TableOutlet.hidden=YES;

   // [[FilterButtonOutlet layer] setBorderColor:[UIColor whiteColor].CGColor];

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
-(void)ShowSelectedDate
{
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"YYYY-M-dd"];
    if ([DatePickerText isFirstResponder])
    {
        DatePickerText.text=[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]];
        ///////////////////////
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"EEEE"];
        NSLog(@"The day of the week: %@", [dateFormatter stringFromDate:datePicker.date]);
        NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
        [gregorian setFirstWeekday:2];
        // NSDateComponents *comps = [gregorian components:NSCalendarUnitWeekday fromDate:datePicker.date];
        NSUInteger adjustedWeekdayOrdinal = [gregorian ordinalityOfUnit:NSWeekdayCalendarUnit inUnit:NSWeekCalendarUnit forDate:datePicker.date];
        NSLog(@"Adjusted weekday ordinal: %d", adjustedWeekdayOrdinal);
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
        NSDateComponents *components=[[NSDateComponents alloc] init];
        if (adjustedWeekdayOrdinal==1) {
            components.day=0;
            NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
            ;
            NSLog(@"%@",targetDate);
            stringDateOutlet = [formatter stringFromDate:targetDate];
        }
        else if (adjustedWeekdayOrdinal==2)
        {
            
            components.day=-1;
            NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
            ;
            NSLog(@"%@",targetDate);
            stringDateOutlet = [formatter stringFromDate:targetDate];
            NSLog(@"%@",stringDateOutlet);
            //FromDateTxtOutlet.text=stringDateOutlet;
            
        }
        else if (adjustedWeekdayOrdinal==3)
        {
            components.day=-2;
            NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
            ;
            NSLog(@"%@",targetDate);
            stringDateOutlet = [formatter stringFromDate:targetDate];
            NSLog(@"%@",stringDateOutlet);
            // FromDateTxtOutlet.text=stringDateOutlet;
            
            
            
        }
        else if (adjustedWeekdayOrdinal==4)
        {
            components.day=-3;
            NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
            ;
            NSLog(@"%@",targetDate);
            stringDateOutlet = [formatter stringFromDate:targetDate];
            NSLog(@"%@",stringDateOutlet);
            // FromDateTxtOutlet.text=stringDateOutlet;
        }
        else if (adjustedWeekdayOrdinal==5)
        {
            components.day=-4;
            NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
            ;
            NSLog(@"%@",targetDate);
            stringDateOutlet = [formatter stringFromDate:targetDate];
            NSLog(@"%@",stringDateOutlet);
            // FromDateTxtOutlet.text=stringDateOutlet;
            
            
        }
        else if (adjustedWeekdayOrdinal==6)
        {
            components.day=-5;
            NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
            ;
            NSLog(@"%@",targetDate);
            stringDateOutlet = [formatter stringFromDate:targetDate];
            NSLog(@"%@",stringDateOutlet);
            // FromDateTxtOutlet.text=stringDateOutlet;
            
            
        }
        else if (adjustedWeekdayOrdinal==7)
        {
            components.day=-6;
            NSDate *targetDate =[calendar dateByAddingComponents:components toDate:datePicker.date options: 0]
            ;
            NSLog(@"%@",targetDate);
            stringDateOutlet = [formatter stringFromDate:targetDate];
            NSLog(@"%@",stringDateOutlet);
            // FromDateTxtOutlet.text=stringDateOutlet;
            
            
            
        }
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setDateFormat:@"yyyy-MM-dd"];
        NSDate *date3 = [dateFormat dateFromString:stringDateOutlet];
        NSDateComponents *components1 = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate:date3];
        
        int year = [components1 year];
        int month = [components1 month];
        int day = [components1 day];
        
        
        components.day=+6;
        NSDate *targetDate =[calendar dateByAddingComponents:components toDate:date3 options: 0]
        ;
        NSLog(@"%@",targetDate);
        ToStringDate = [formatter stringFromDate:targetDate];
        NSLog(@"%@",ToStringDate);
        
        //[datePicker removeFromSuperview];
        //[tool removeFromSuperview];

        
        
        
        
        [DatePickerText resignFirstResponder];
    }
}

#pragma tableview delegate methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [HoursArray count]; //one male and other female
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"SubmitTableViewCell";
    
   SubmitTableViewCell*cell2 = (SubmitTableViewCell *)[TableOutlet dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell2 == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SubmitTableViewCell" owner:self options:nil];
        cell2 = [nib objectAtIndex:0];
        TableOutlet.separatorStyle = UITableViewCellSeparatorStyleNone;
        cell2.layer.cornerRadius=5;
        cell2.layer.borderWidth=1.5;
        cell2.DateView.layer.cornerRadius=5;
        [[cell2 layer] setBorderColor:[UIColor lightGrayColor].CGColor];
        
        CAGradientLayer *gradient = [CAGradientLayer layer];
        gradient.cornerRadius=5;
        gradient.frame = cell2.DateView.bounds;
        gradient.colors = [NSArray arrayWithObjects:(id)[[UIColor blackColor] CGColor], (id)[[UIColor redColor] CGColor], nil];
        [cell2.DateView.layer insertSublayer:gradient atIndex:0];
        
        cell2.DayLabelOutlet.text=[DayArray objectAtIndex:indexPath.section];
        cell2.HoursLabelOutlet.text=[[HoursArray objectAtIndex:indexPath.section]stringValue];

       
    }
    return cell2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 52;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 5.; // you can have your own choice, of course
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)BackButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)ViewMoreButtonTapped:(id)sender {
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
    [self presentViewController:vc animated:YES completion:nil];
    
    
}

- (IBAction)FilterButtonTapped:(id)sender {
    if ([DatePickerText.text isEqualToString:@""]) {
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Warning"
                                     message:@"Please select date"
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* yesButton = [UIAlertAction
                                    actionWithTitle:@"ok"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        
                                        
                                        
                                        
                                        //Handle your yes please button action here
                                    }];
        
        
        [alert addAction:yesButton];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }
    else
    {
        HoursArray=[[NSMutableArray alloc]init];

        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/MGet_FilterWeeklyEntry"]];
        AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
        NSString *UserName=appDelegate.UserName;
        NSDictionary *o1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:stringDateOutlet, @"sIN_BeginDate",UserName, @"sIN_UserCode",nil];
       NSMutableArray *FilterInputArray=[NSMutableArray arrayWithObject:o1];
        //create the Method "GET" or "POST"
        NSError *error;
        [request setHTTPMethod:@"POST"];
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:FilterInputArray options:NSJSONWritingPrettyPrinted error:&error];
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSString *jsonString1=[NSString stringWithFormat:@"sJsonInput=%@",jsonString];
        //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
        // NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput={'sDBName' : 'ABEO_INTL'}"];
        
        
        
        //Check The Value what we passed
        // NSLog(@"the data Details is =%@", userUpdate);
        
        //Convert the String to Data
        NSData *data1 = [jsonString1 dataUsingEncoding:NSUTF8StringEncoding];
        //[request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
        //NSLog(@"%@",InputArray);
        
        //Apply the data to the body
        [request setHTTPBody:data1];
        NSError *err;
        NSURLResponse *response;
        
        NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
        
        NSString *resSrt = [[NSString alloc]initWithData:responseData encoding:NSASCIIStringEncoding];
        NSLog(@"got response==%@", resSrt);
        if(resSrt)
        {
            NSLog(@"got response");
        }
        else
        {
            NSLog(@"faield to connect");
        }
        
        NSError *e = nil;
        NSMutableArray *json1 = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&e];
        //at=[json objectAtIndex:4];
            
        
        
        NSLog(@"%@",json1);
        Mon=[json1 valueForKey:@"Mon"];
        Tue=[json1 valueForKey:@"Tue"];
        Wed=[json1 valueForKey:@"Wed"];
        Thu=[json1 valueForKey:@"Thu"];
        Fri=[json1 valueForKey:@"Fri"];
        Sat=[json1 valueForKey:@"Sat"];
        Sun=[json1 valueForKey:@"Sun"];

        
        //NSMutableArray *myA=[[NSMutableArray alloc]initWithObjects:@"1.00",@"2.50",@"3.0",@"5.0", nil];
        float sum = 0;
        for (NSNumber *num in Mon)
        {
            sum += [num floatValue];
        }
        NSLog(@"%.2f",sum);
        sum = [[NSString stringWithFormat:@"%f",sum]floatValue];

        NSNumber *yourFloatNumber = [NSNumber numberWithFloat:sum];
        [HoursArray addObject:yourFloatNumber];
        ///////////////////////////////////////
        float sum1 = 0;
        for (NSNumber *num in Tue)
        {
            sum1 += [num floatValue];
        }
        NSLog(@"%.2f",sum);
        sum1 = [[NSString stringWithFormat:@"%f",sum1]floatValue];
        
        NSNumber *yourFloatNumber1 = [NSNumber numberWithFloat:sum1];
        [HoursArray addObject:yourFloatNumber1];
        NSLog(@"%@",HoursArray);
        
///////////////////////////////////////////
        
        float sum2 = 0;
        for (NSNumber *num in Wed)
        {
            sum2 += [num floatValue];
        }
        NSLog(@"%.2f",sum);
        sum = [[NSString stringWithFormat:@"%f",sum2]floatValue];
        
        NSNumber *yourFloatNumber2 = [NSNumber numberWithFloat:sum2];
        [HoursArray addObject:yourFloatNumber2];
       // NSLog(@"%@",mon1);
        ///////////////////////////////////////////////

        float sum3 = 0;
        for (NSNumber *num in Thu)
        {
            sum3 += [num floatValue];
        }
        NSLog(@"%.2f",sum);
        sum3 = [[NSString stringWithFormat:@"%f",sum3]floatValue];
        
        NSNumber *yourFloatNumber3 = [NSNumber numberWithFloat:sum3];
        [HoursArray addObject:yourFloatNumber3];
       // NSLog(@"%@",thu1);
        ////////////////////////////////////////////////
        
        float sum4 = 0;
        for (NSNumber *num in Fri)
        {
            sum4 += [num floatValue];
        }
        NSLog(@"%.2f",sum);
        sum4 = [[NSString stringWithFormat:@"%f",sum4]floatValue];
        
        NSNumber *yourFloatNumber4 = [NSNumber numberWithFloat:sum4];
        [HoursArray addObject:yourFloatNumber4];
       // NSLog(@"%@",fri1);

///////////////////////////////////////////////////////////////
        float sum5 = 0;
        for (NSNumber *num in Sat)
        {
            sum5 += [num floatValue];
        }
        NSLog(@"%.2f",sum5);
        sum5 = [[NSString stringWithFormat:@"%f",sum5]floatValue];
        
        NSNumber *yourFloatNumber5 = [NSNumber numberWithFloat:sum5];
        [HoursArray addObject:yourFloatNumber5];
       // NSLog(@"%@",sat1);

        /////////////////////////////////////////////////////////
        
        float sum6 = 0;
        for (NSNumber *num in Sun)
        {
            sum6 += [num floatValue];
        }
        NSLog(@"%.2f",sum);
        sum6 = [[NSString stringWithFormat:@"%f",sum6]floatValue];
        
        NSNumber *yourFloatNumber6 = [NSNumber numberWithFloat:sum6];
        [HoursArray addObject:yourFloatNumber6];
        NSLog(@"%i",[HoursArray count]);
        
        NSLog(@"%i",HoursArray);
    
    InputArray=[[NSMutableArray alloc]init];
        /*
    for (int i=0;i<[json count]; i++) {
        NSString *ids=[[json objectAtIndex:i]valueForKey:@"IDS"];
        NSString *StatusString=[[json objectAtIndex:i]valueForKey:@"Status"];
        NSLog(@"%@",ids);
        DICT=[NSMutableDictionary dictionaryWithObjectsAndKeys:ids,@"IDS",StatusString,@"Status", nil];
        [InputArray addObject:DICT];
    }
         */
    }
    TableOutlet.hidden=NO;
    TableOutlet.dataSource=self;
    TableOutlet.delegate=self;
    [TableOutlet reloadData];
}

- (IBAction)SubmitButtonTapped:(id)sender {
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://54.251.51.69:3990/Mobile.asmx/SubmitForPMApproval"]];
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
   // NSString *UserName=appDelegate.UserName;
   
    //create the Method "GET" or "POST"
    NSError *error;
    [request setHTTPMethod:@"POST"];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:InputArray options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *jsonString1=[NSString stringWithFormat:@"sJsonInput=%@",jsonString];
    //Pass The String to server(YOU SHOULD GIVE YOUR PARAMETERS INSTEAD OF MY PARAMETERS)
    // NSString *userUpdate =[NSString stringWithFormat:@"sJsonInput={'sDBName' : 'ABEO_INTL'}"];
    
    
    
    //Check The Value what we passed
    // NSLog(@"the data Details is =%@", userUpdate);
    
    //Convert the String to Data
    NSData *data1 = [jsonString1 dataUsingEncoding:NSUTF8StringEncoding];
    //[request setValue:@"length" forHTTPHeaderField:@"Content-Length"];
    //NSLog(@"%@",InputArray);
    
    //Apply the data to the body
    [request setHTTPBody:data1];
    NSError *err;
    NSURLResponse *response;
    
    NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&err];
    
    NSString *resSrt = [[NSString alloc]initWithData:responseData encoding:NSASCIIStringEncoding];
    NSLog(@"got response==%@", resSrt);
    if(resSrt)
    {
        NSLog(@"got response");
    }
    else
    {
        NSLog(@"faield to connect");
    }
    
    NSError *e = nil;
    NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:&e];
    
    NSString *ResultString=[[json valueForKey:@"Result"]objectAtIndex:0];
    
    if ([ResultString isEqualToString:@"SUCCESS"]) {
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Success" message:@"Timesheet submitted Successfully" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
    else
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Warning" message:@"Error occured in Submitted timesheet" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }

}
@end
