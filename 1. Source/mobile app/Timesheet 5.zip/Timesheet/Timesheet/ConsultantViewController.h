//
//  ConsultantViewController.h
//  Timesheet
//
//  Created by electra on 1/24/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ConsultantTableViewCell.h"
#import "AppDelegate.h"

@interface ConsultantViewController : UIViewController<UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>
{
    UITableView *dropDownTableView,*dropDownTableView1;
    NSMutableArray *ProjectNameArray,*searchArray,*ConsultantArray,*SearchArray1,*DisplayArray,*ProjectCodeArray,*prjArray;
    NSMutableArray *InputArray,*NoConId;
    NSString *searchTextString,*sjc,*UserId,*ConIdString,*PassString1,*prjString,*SaveString,*jsonString1,*jsonStr;
    NSMutableDictionary *o1;
}
@property (strong, nonatomic) IBOutlet UIButton *AddButtonOutlet;
@property (strong, nonatomic) IBOutlet UITextField *ProjectNameTxtOutlet;
@property (strong, nonatomic) IBOutlet UITextField *ConsultantTxtOutlet;
@property (strong, nonatomic) IBOutlet UITableView *DisplayTableOutlet;
@property (strong, nonatomic) IBOutlet UIImageView *ArrowImg1;
@property (strong, nonatomic) IBOutlet UIImageView *ArrowImg2;

- (IBAction)AddButtonTapped:(id)sender;
- (IBAction)LogoutButtonTapped:(id)sender;
- (IBAction)BackButtonTapped:(id)sender;
- (IBAction)SaveButtonTapped:(id)sender;
- (IBAction)ClearButtonTapped:(id)sender;

@end
