//
//  MenuViewController.m
//  Timesheet
//
//  Created by electra on 1/10/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import "MenuViewController.h"

@interface MenuViewController ()

@end

@implementation MenuViewController
{
    UIAlertView *LogoutAlert;
}
@synthesize MenuViewOutlet,DateLabelOutlet,MenuTableViewOutlet,DayOutletLabel,MenuTableItemArray,MenuTableImgArray,str;

- (void)viewDidLoad {
    [super viewDidLoad];

    NSLog(@"%@",MenuTableItemArray);

   // MenuTableItemArray=[[NSMutableArray alloc]init];
    //corner radius
    MenuViewOutlet.layer.cornerRadius=5;
    //current time and date
    [NSTimer scheduledTimerWithTimeInterval:1.0
                                     target:self
                                   selector:@selector(timeNotify)
                                   userInfo:nil
                                    repeats:YES];
    
    NSDateFormatter *formatter;
    NSString        *dateString;
    
    formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd-MM-yyyy"];
    dateString = [formatter stringFromDate:[NSDate date]];
    DateLabelOutlet.text=dateString;
    NSDateFormatter* day = [[NSDateFormatter alloc] init];
    [day setDateFormat: @"EEEE"];
    NSString *dayString=[day stringFromDate:[NSDate date]];
    DayOutletLabel.text=dayString;
    
    
    
   // MenuTableItemArray=[[NSMutableArray alloc]init];
   // MenuTableImgArray=[[NSMutableArray alloc]init];
    MenuTableViewOutlet.separatorStyle=UITableViewCellSeparatorStyleNone;
}
- (void) timeNotify
{
    NSDate *currentTime = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"hh:mm a"];
    NSString *resultString = [dateFormatter stringFromDate: currentTime];
    _TimeLabelOutlet.text = resultString;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    [super viewWillAppear:animated];
    
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
/*
#pragma mark -

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma tableview delegate methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [MenuTableItemArray count]; //one male and other female
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"MenuTableViewCell";
    
    MenuTableViewCell*cell = (MenuTableViewCell *)[MenuTableViewOutlet dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MenuTableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        cell.MenuLabelOutlet.text=[MenuTableItemArray objectAtIndex:indexPath.section];
        cell.MenuTableImgOutlet.image=[UIImage imageNamed:[MenuTableImgArray objectAtIndex:indexPath.section]];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.layer.cornerRadius=5;
        cell.layer.borderWidth=1.5;
        [[cell layer] setBorderColor:[UIColor lightGrayColor].CGColor];

    }
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 5.; // you can have your own choice, of course
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    NSString * storyboardName = @"Main";

    if (indexPath.section==0) {

        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
       WeeklyViewController *WeekVC=[[WeeklyViewController alloc]init];
         WeekVC = [storyboard instantiateViewControllerWithIdentifier:@"WeeklyViewController"];
       // UINavigationController *navCtrl = [[UINavigationController alloc] initWithRootViewController:WeekVC];

        [self.navigationController pushViewController:WeekVC animated:YES];
    }
    else if (indexPath.section==1){
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"MyEntryViewController"];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else if (indexPath.section==2)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"ApproveViewController"];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else if (indexPath.section==3)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"PMApprovalViewController"];
        [self.navigationController pushViewController:vc animated:YES];
        
    }
    else if (indexPath.section==4)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"ConsultantViewController"];
        [self.navigationController pushViewController:vc animated:YES];
        
    }


}
- (IBAction)LogoutButtonTapped:(id)sender {
    LogoutAlert = [[UIAlertView alloc]
                   initWithTitle:@"Confirmation"
                   message:@"Are you sure you want to Logout"
                   delegate:self
                   cancelButtonTitle:@"No"
                   otherButtonTitles:@"yes",nil];
    [LogoutAlert show];
    LogoutAlert.delegate=self;
     //[self.navigationController popToRootViewControllerAnimated:YES];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if(buttonIndex == 0)//OK button pressed
    {
        NSLog(@"0");
    }
    else if(buttonIndex == 1)//Annul button pressed.
    {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
}
- (IBAction)BackButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
@end
