//
//  ConsultantTableViewCell.m
//  Timesheet
//
//  Created by electra on 1/25/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import "ConsultantTableViewCell.h"

@implementation ConsultantTableViewCell
@synthesize ProjectNameOutlet,SnoLabelOutlet;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
