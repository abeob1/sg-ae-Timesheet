//
//  SearchTableViewCell.h
//  Timesheet
//
//  Created by electra on 1/11/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UITextView *ProjectNameOutlet;
@property (strong, nonatomic) IBOutlet UILabel *ProjectCodeOutlet;

@end
