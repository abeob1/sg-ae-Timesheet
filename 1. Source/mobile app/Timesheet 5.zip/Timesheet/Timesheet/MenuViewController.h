//
//  MenuViewController.h
//  Timesheet
//
//  Created by electra on 1/10/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuTableViewCell.h"
#import "WeeklyViewController.h"

@interface MenuViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
   // NSMutableArray *MenuTableItemArray,*MenuTableImgArray;
}
//@property(strong,nonatomic)WeeklyViewController *WeekVC;
@property (strong, nonatomic) IBOutlet UIView *MenuViewOutlet;
@property (strong, nonatomic) IBOutlet UILabel *DateLabelOutlet;
@property (strong, nonatomic) IBOutlet UITableView *MenuTableViewOutlet;
@property (strong, nonatomic) IBOutlet UILabel *DayOutletLabel;
@property(strong,nonatomic)NSMutableArray *MenuTableItemArray;
@property(strong,nonatomic)NSMutableArray *MenuTableImgArray;
@property(strong,nonatomic)NSMutableString *str;
//@property(strong,nonatomic)AppDelegate *App;

- (IBAction)LogoutButtonTapped:(id)sender;

- (IBAction)BackButtonTapped:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *TimeLabelOutlet;

@end
