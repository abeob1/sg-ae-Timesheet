//
//  ViewController.h
//  Timesheet
//
//  Created by electra on 1/10/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuViewController.h"

@interface ViewController : UIViewController<UITextFieldDelegate>
{
    UIAlertView *WrongAlert;
    NSMutableArray *TableItemArray,*TableImgArray;
}
@property (strong, nonatomic) IBOutlet UITextField *UsernameTxtOutlet;
@property (strong, nonatomic) IBOutlet UITextField *PasswordTxtOutlet;
@property (strong, nonatomic) IBOutlet UIButton *LoginButtonOutlet;
@property (strong, nonatomic) IBOutlet UIView *LoginViewOutlet;
@property(strong,nonatomic)MenuViewController *MenuVC;
@property(strong,nonatomic)NSMutableArray *TableItemArray;
@property(strong,nonatomic)NSMutableArray *TableImgArra;

- (IBAction)LoginButtonTapped:(id)sender;


@end

