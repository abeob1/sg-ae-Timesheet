//
//  SubmitTableViewCell.h
//  Timesheet
//
//  Created by electra on 1/17/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubmitTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIView *DateView;
@property (strong, nonatomic) IBOutlet UILabel *HoursLabelOutlet;
@property (strong, nonatomic) IBOutlet UILabel *DayLabelOutlet;

@end
