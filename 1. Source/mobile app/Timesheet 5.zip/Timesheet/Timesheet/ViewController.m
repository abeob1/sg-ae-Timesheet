//
//  ViewController.m
//  Timesheet
//
//  Created by electra on 1/10/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize UsernameTxtOutlet,PasswordTxtOutlet,LoginButtonOutlet,LoginViewOutlet,MenuVC;

- (void)viewDidLoad {
    [super viewDidLoad];
    CALayer *border1 = [CALayer layer];
    CGFloat borderWidth = 1.2;
    border1.borderColor = [UIColor darkGrayColor].CGColor;
    border1.frame = CGRectMake(0,UsernameTxtOutlet.frame.size.height - borderWidth,UsernameTxtOutlet.frame.size.width,UsernameTxtOutlet.frame.size.height);
    border1.borderWidth = borderWidth;
    [UsernameTxtOutlet.layer addSublayer:border1];
    UsernameTxtOutlet.layer.masksToBounds = YES;
    
    CALayer *border = [CALayer layer];
    //CGFloat borderWidth = 1.2;
    border.borderColor = [UIColor darkGrayColor].CGColor;
    border.frame = CGRectMake(0, PasswordTxtOutlet.frame.size.height - borderWidth,PasswordTxtOutlet.frame.size.width,PasswordTxtOutlet.frame.size.height);
    border.borderWidth = borderWidth;
    [PasswordTxtOutlet.layer addSublayer:border];
    PasswordTxtOutlet.layer.masksToBounds = YES;
    
    LoginButtonOutlet.layer.cornerRadius=20;
    LoginViewOutlet.layer.cornerRadius=5;

    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)LoginButtonTapped:(id)sender {
    NSString * storyboardName = @"Main";

    
    if([UsernameTxtOutlet.text isEqualToString:@"user1"] && [PasswordTxtOutlet.text isEqualToString:@"test123"])
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        MenuVC = [storyboard instantiateViewControllerWithIdentifier:@"MenuViewController"];
        TableItemArray=[[NSMutableArray alloc]initWithObjects:@"Weekly Entry",@"My Entry",@"Submit PM Approval", nil];
        TableImgArray=[[NSMutableArray alloc]initWithObjects:@"weeklyEntry.png",@"MYEntry.png",@"pmapp.png", nil];
        //MenuVC=[[MenuViewController alloc]init];

        MenuVC.MenuTableItemArray=TableItemArray;
        MenuVC.MenuTableImgArray=TableImgArray;
        [self.navigationController pushViewController:MenuVC animated:YES];


    }
    else if ([UsernameTxtOutlet.text isEqualToString:@"user2"] && [PasswordTxtOutlet.text isEqualToString:@"test123"])
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        MenuVC = [storyboard instantiateViewControllerWithIdentifier:@"MenuViewController"];
        TableItemArray=[[NSMutableArray alloc]initWithObjects:@"Weekly Entry",@"My Entry",@"Submit PM Approval",@"Pending for PM Approval", nil];
        TableImgArray=[[NSMutableArray alloc]initWithObjects:@"weeklyEntry.png",@"MYEntry.png",@"pmapp.png",@"time4.png",nil];
        MenuVC.MenuTableItemArray=TableItemArray;
        MenuVC.MenuTableImgArray=TableImgArray;
        [self.navigationController pushViewController:MenuVC animated:YES];


    }
    else if ([UsernameTxtOutlet.text  isEqualToString:@""]||[PasswordTxtOutlet.text isEqualToString:@""])
    {
        UIAlertView *WrongAlert = [[UIAlertView alloc]
                                   initWithTitle:@""
                                   message:@"Please enter uesrname and password"
                                   delegate:self
                                   cancelButtonTitle:@"ok"
                                   otherButtonTitles:nil];
        [WrongAlert show];
    }
    else if ([UsernameTxtOutlet.text isEqualToString:@""])
    {
WrongAlert.message=@"please enter username";
        [WrongAlert show];
    }
    else if ([PasswordTxtOutlet.text isEqualToString:@""])
    {
        WrongAlert.message=@"please enter password";
        [WrongAlert show];

    }
    else
    { UIAlertView *WrongAlert1 = [[UIAlertView alloc]
                                 initWithTitle:@"Login Problem"
                                 message:@"wrong username/password"
                                 delegate:self
                                 cancelButtonTitle:@"ok"
                                 otherButtonTitles:nil];
        [WrongAlert1 show];

           }
    /*
    else
    {
       UIAlertView *WrongAlert = [[UIAlertView alloc]
                       initWithTitle:@"Login Problem"
                       message:@"Wrong username/password"
                       delegate:self
                       cancelButtonTitle:@"ok"
                       otherButtonTitles:nil];
        [WrongAlert show];
       // LogoutAlert.delegate=self;

    }
     
     
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"MenuViewController"];
     */
    //[self.navigationController pushViewController:vc animated:YES];

   }

- (void)viewWillAppear:(BOOL)animated {
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    [super viewWillAppear:animated];

    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark - keyboard movements
- (void)keyboardWillShow:(NSNotification *)notification
{
    CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    [UIView animateWithDuration:0.3 animations:^{
        CGRect f = self.view.frame;
        f.origin.y = -80;
        self.view.frame = f;
    }];
}

-(void)keyboardWillHide:(NSNotification *)notification
{
    [UIView animateWithDuration:0.3 animations:^{
        CGRect f = self.view.frame;
        f.origin.y = 0.0f;
        self.view.frame = f;
    }];
}

 -(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [UsernameTxtOutlet resignFirstResponder];
    [PasswordTxtOutlet resignFirstResponder];
    return YES;
}
@end
