//
//  PMApprovalViewController.h
//  Timesheet
//
//  Created by electra on 1/17/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PendingTableViewCell.h"
#import "AppDelegate.h"

@interface PMApprovalViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>
{
    UIDatePicker *datePicker;
    UIToolbar *toolBar;
    UITableView *dropDownTableView,*dropDownTableView2;
    NSMutableArray *UserNameArray,*UserIdArray,*sArray,*projectNameArray,*statusArray,*hourArray,*DateArray;
    NSString *UserIdString,*Status1;
}
@property (strong, nonatomic) IBOutlet UIButton *FilterButtonOutlet;
@property (strong, nonatomic) IBOutlet UITableView *MainTableViewOutlet;
@property (strong, nonatomic) IBOutlet UIButton *SelectButtonOutlet;
@property (strong, nonatomic) IBOutlet UITextField *FromDateTxtOutlet;
@property (strong, nonatomic) IBOutlet UITextField *ToDateTxtOutlet;
@property (strong, nonatomic) IBOutlet UITextField *DropDownTxtOutlet;
@property (strong, nonatomic) IBOutlet UITextField *DropDownTxt2Outlet;
@property (strong, nonatomic) IBOutlet UILabel *NodataFoundLabelOutlet;
@property (strong, nonatomic) IBOutlet UIView *UnderView;

- (IBAction)DatePickerButton1Tapped:(id)sender;
- (IBAction)DatePickerButton2Tapped:(id)sender;

- (IBAction)BackButtonTapped:(id)sender;
- (IBAction)ApproveButtonTapped:(id)sender;
- (IBAction)RejectButtonTapped:(id)sender;

- (IBAction)FilterButtonTapped:(id)sender;


@end
