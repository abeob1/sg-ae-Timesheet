//
//  AppDelegate.h
//  Timesheet
//
//  Created by electra on 1/10/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property(strong,nonatomic)NSMutableArray *PassArray;
@property(strong,nonatomic)NSMutableArray *PassImgArray;

//@property(strong,nonatomic)MenuViewController *MenuVC;
@property(strong,nonatomic)NSString *UserIdString,*UserName,*DbName;


@end

