//
//  MyEntryTableViewCell.h
//  Timesheet
//
//  Created by electra on 1/14/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyEntryTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *ProJectNameOutlet;
@property (strong, nonatomic) IBOutlet UILabel *DateOutlet;
@property (strong, nonatomic) IBOutlet UILabel *ProjectCodeOutlet;
@property (strong, nonatomic) IBOutlet UILabel *HourLabelOutlet;

@end
