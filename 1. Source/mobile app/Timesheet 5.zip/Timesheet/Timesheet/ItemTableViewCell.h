//
//  ItemTableViewCell.h
//  Timesheet
//
//  Created by electra on 1/11/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ItemTableViewCell : UITableViewCell<UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UILabel *ProjectNameOutlet;
@property (strong, nonatomic) IBOutlet UILabel *ProjectCodeOutlet;
@property (strong, nonatomic) IBOutlet UILabel *FromDateOutlet;
@property (strong, nonatomic) IBOutlet UILabel *TodateOutlet;
@property (strong, nonatomic) IBOutlet UITextField *MonOutlet;
@property (strong, nonatomic) IBOutlet UITextField *TueOutlet;
@property (strong, nonatomic) IBOutlet UITextField *WedOutlet;
@property (strong, nonatomic) IBOutlet UITextField *ThuOutlet;
@property (strong, nonatomic) IBOutlet UITextField *FriOutlet;

@property (strong, nonatomic) IBOutlet UITextField *SatOutlet;
@property (strong, nonatomic) IBOutlet UITextField *SunOutlet;
@property (strong, nonatomic) IBOutlet UILabel *TotalOutLet;
@property (strong, nonatomic) IBOutlet UILabel *StatusOutputLabel;
@property (strong, nonatomic) IBOutlet UISegmentedControl *SegmentControll;
@property (strong, nonatomic) IBOutlet UILabel *StatusInputLabel;
@property (strong, nonatomic) IBOutlet UITextField *TaskOutlet;


@end
