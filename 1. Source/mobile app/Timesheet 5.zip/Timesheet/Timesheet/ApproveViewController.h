//
//  ApproveViewController.h
//  Timesheet
//
//  Created by electra on 1/13/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SubmitTableViewCell.h"
#import "AppDelegate.h"

@interface ApproveViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *HoursArray,*DayArray;
    UIDatePicker *datePicker;
    NSString *stringDateOutlet,*ToStringDate;
    NSMutableArray *Mon,*Tue,*Wed,*Thu,*Fri,*Sat,*Sun,*InputArray;


}
@property (strong, nonatomic) IBOutlet UITableView *TableOutlet;
@property (strong, nonatomic) IBOutlet UIButton *ViewMoreButtonOutlet;


- (IBAction)BackButtonTapped:(id)sender;
- (IBAction)ViewMoreButtonTapped:(id)sender;
- (IBAction)FilterButtonTapped:(id)sender;
- (IBAction)SubmitButtonTapped:(id)sender;

@property (strong, nonatomic) IBOutlet UITextField *DatePickerText;

@end
