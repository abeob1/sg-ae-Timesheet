//
//  DetailViewController.m
//  Timesheet
//
//  Created by electra on 1/18/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController
@synthesize TableViewOutlet;

- (void)viewDidLoad {
    [super viewDidLoad];
    _AddButtonOutlet.layer.cornerRadius=3;

    datePicker = [[UIDatePicker alloc]init];
    datePicker.datePickerMode = UIDatePickerModeDate;
    [_DateTxtOutlet setInputView:datePicker];
    UIToolbar *toolBar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,35)];
    [toolBar setTintColor:[UIColor grayColor]];
    UIBarButtonItem *doneBtn = [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(ShowSelectedDate)];
    UIBarButtonItem *space = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [toolBar setItems:[NSArray arrayWithObjects:space,doneBtn, nil]];
    
    [_DateTxtOutlet setInputAccessoryView:toolBar];
    

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)ShowSelectedDate
{
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"YYYY-M-dd"];
    if ([_DateTxtOutlet isFirstResponder])
    {
        _DateTxtOutlet.text=[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]];
        [_DateTxtOutlet resignFirstResponder];
    }
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)AddButtonTapped:(id)sender {
}

- (IBAction)FilterButtonTapped:(id)sender {
}

- (IBAction)BackButtonTapped:(id)sender {
    [self dismissViewControllerAnimated:NO completion:nil];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
    
   }

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
        static NSString *simpleTableIdentifier = @"ItemTableViewCell";
        
        ItemTableViewCell*cell1 = (ItemTableViewCell *)[TableViewOutlet dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell1 == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ItemTableViewCell" owner:self options:nil];
            cell1 = [nib objectAtIndex:0];
            //SearchtableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
            cell1.layer.cornerRadius=5;
            cell1.layer.borderWidth=1;
            
    }
        return cell1;
    }
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 212;
}

    

@end
