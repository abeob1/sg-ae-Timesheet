//
//  WeeklyViewController.h
//  Timesheet
//
//  Created by electra on 1/10/17.
//  Copyright © 2017 electra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddViewController.h"
#import "SearchTableViewCell.h"
#import "ItemTableViewCell.h"
#import "AppDelegate.h"

@interface WeeklyViewController : UIViewController<UITextFieldDelegate>
{
    UIView *SearchView;
    UISearchBar * searchBar;
    UITableView * SearchtableView;
    IBOutlet UILabel *DatatNotFoundLabel;
    UIDatePicker *datePicker;
    NSMutableArray *FilterInputArray,*ProjectCode,*ProjectName,*Mon,*Tue,*Wed,*Thu,*Fri,*Sat,*Sun,*TotalArray;
    NSString *stringDateOutlet,*UserName,*ToStringDate,*StatusString,*SegmentTitleone,*SegmentTitle2,*mon,*tue,*wed,*thu,*fri,*sat,*sun,*task,*idssString;
    NSMutableArray *ProjectName1,*PsTo,*ProjectCode1,*IDsArray,*TaskArray,*StatusArray;
}
@property (strong, nonatomic) IBOutlet UIButton *ClearButton;

@property (strong, nonatomic) IBOutlet UITextField *FromTextOutlet;
@property (strong, nonatomic) IBOutlet UIButton *AddButtonOutlet;
@property (strong, nonatomic) IBOutlet UIButton *SaveEntryButtonOutlet;
@property(strong,nonatomic)NSString *SaveString,*dbName;
@property (strong, nonatomic) IBOutlet UITableView *TableViewOutlet;


- (IBAction)CalenderButtonTapped:(id)sender;
//@property(strong,nonatomic)AddViewController *AddView;
//@property(strong,nonatomic)AddViewController *AddView;
@property(strong,nonatomic)NSMutableArray *TableReceiveArray;

@property (strong, nonatomic) IBOutlet UITextField *FromDateTxtOutlet;

- (IBAction)LogoutButtonTapped:(id)sender;

- (IBAction)BackButtonTapped:(id)sender;
- (IBAction)AddButtonTapped:(id)sender;
- (IBAction)FilterButtonTapped:(id)sender;
- (IBAction)ClearButtonTapped:(id)sender;

@end
